# USER.md - About Your Human

- **Name:** Akshay Joshi
- **What to call them:** Akshay
- **Pronouns:** 
- **Timezone:** Asia/Calcutta
- **Notes:** 
