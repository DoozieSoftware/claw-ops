# ClawOps Security Skill

> **What this does:** Validates tokens, enforces immutability, and runs SOUL validation on every action.

## Overview

This skill is **installed on client's OpenClaw** and provides:

1. **Token Verification** — Validates ClawOps-signed tokens locally (works offline!)
2. **Immutability Enforcement** — Locks filesystem on startup
3. **SOUL Validation** — Runs before every action
4. **Audit Logging** — Logs all actions and violations

## Files

```
clawops-security/
├── SKILL.md              # Main documentation (you are here)
├── README.md             # Quick start guide
├── skill.yaml            # Skill manifest
├── package.json          # Node.js dependencies
├── config.yaml           # Client configuration template
├── public_key.pem        # ClawOps public key (placeholder)
├── hooks/
│   ├── pre-action.js     # Runs before every action (SOUL validation)
│   └── post-action.js    # Runs after every action (audit logging)
├── scripts/
│   ├── token_validator.py      # Token verification (offline!)
│   └── immutability_enforcer.py # Filesystem lockdown
└── utils/
    └── config-loader.js  # YAML config loader
```

## Installation

```bash
# On CLIENT's OpenClaw instance
cd ~/.openclaw/skills
git clone https://github.com/DoozieSoftware/claw-ops-security.git clawops-security
cd clawops-security
npm install
```

## Configuration

Edit `config.yaml`:

```yaml
security:
  # Path to client's SOUL.md
  soul_path: /root/.openclaw/clients/my-client/SOUL.md
  
  # Path to USE_CASES folder
  use_case_path: /root/.openclaw/clients/my-client/USE_CASES
  
  # ClawOps public key for token verification
  # (Get this from ClawOps after onboarding)
  clawops_public_key: |
    -----BEGIN PUBLIC KEY-----
    MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDdlatRjRjogo3WojgGHFHYLugd...
    -----END PUBLIC KEY-----
  
  # Immutability settings
  immutability:
    enabled: true
    lock_on_startup: true
    check_interval_minutes: 5
    
  # Audit logging
  audit:
    enabled: true
    path: /root/.openclaw/logs/security-audit.jsonl
```

## How Token Verification Works (Offline!)

```
1. CLAWOPS (MASTER) has PRIVATE KEY
   ↓
2. ClawOps generates token and SIGNS it
   ↓
3. Token sent to client (via Signal/email)
   ↓
4. CLIENT has PUBLIC KEY (embedded in skill)
   ↓
5. Client verifies signature LOCALLY (no network needed!)
   ↓
6. If valid → Allow action
   If invalid → Block + Alert
```

### Token Format (JWT-like)

```
eyJjbGllbnQiOiJhY21lLWNvcnAiLCJ0eXBlIjoibWFzdGVyIiwiZXhwIjo5OTk5OTk5OTk5LCJzaWciOiJhbGdvcml0aG09...
```

**Decoded payload:**
```json
{
  "client": "acme-corp",
  "type": "master",
  "expires_at": 99999999999,
  "sig": "sha256-signed-by-clawops-private-key"
}
```

## Immutability Enforcement

On startup, the skill:
1. Reads SOUL.md and USE_CASES
2. Locks filesystem (IMMUTABLE_CORE + LOCKED_PATHS)
3. Leaves MEMORY/CONTEXT mutable (agent brain!)
4. Sets up file watcher to detect unauthorized changes

## Pre-Action Hook

Every action runs through `pre-action.js`:

```javascript
// hooks/pre-action.js
const { validateAction } = require('../utils/soul_validator');

module.exports = async function preActionHook(context) {
  const { user, channel, action, data } = context;
  
  // 1. Check if system is locked
  if (systemIsLocked && !hasUnlockToken) {
    return { allowed: false, reason: 'SYSTEM_LOCKED' };
  }
  
  // 2. SOUL Validation
  const soulResult = await validateAction(user, channel, action, data);
  if (!soulResult.allowed) {
    logViolation(soulResult.errors);
    return { allowed: false, reason: 'SOUL_VIOLATION', errors: soulResult.errors };
  }
  
  // 3. Check token for config changes
  if (action.requiresConfigAccess && !hasValidToken) {
    return { allowed: false, reason: 'TOKEN_REQUIRED' };
  }
  
  return { allowed: true };
};
```

## Commands

```bash
# Verify a token (offline)
cd /root/.openclaw/skills/clawops-security
python3 scripts/token_validator.py --token "eyJ..."

# Check immutability status
python3 scripts/immutability_enforcer.py --status

# Unlock for editing (requires token)
python3 scripts/immutability_enforcer.py --unlock --token "eyJ..."

# Relock after editing
python3 scripts/immutability_enforcer.py --relock

# Force relock (emergency)
python3 scripts/immutability_enforcer.py --force-relock
```

## Audit Log Format

```jsonl
{"timestamp":"2026-02-06T18:30:00Z","event":"action","user":"user@client.com","channel":"Telegram","action":"query-emails","allowed":true,"duration_ms":45}
{"timestamp":"2026-02-06T18:31:00Z","event":"action","user":"unknown@evil.com","channel":"Telegram","action":"delete-emails","allowed":false,"reason":"SOUL_VIOLATION","violations":["delete-emails BLOCKED"]}
{"timestamp":"2026-02-06T18:32:00Z","event":"unlock","user":"admin@client.com","token_type":"master","allowed":true}
{"timestamp":"2026-02-06T18:33:00Z","event":"lock","user":"system","allowed":true}
{"timestamp":"2026-02-06T18:34:00Z","event":"integrity_check","status":"passed","files_verified":1250}
```

## Setup Flow (Client Onboarding)

```
Step 1: ClawOps Creates Client in Vault
────────────────────────────────────────
ClawOps$ python3 client_vault.py --add-client \
    --name "Acme Corp" \
    --email "admin@acme.com" \
    --channels "Telegram,Slack"

⬇️ Generates:
   - Master Token (signed with ClawOps PRIVATE KEY)
   - Client config

Step 2: Send Installation Package to Client
────────────────────────────────────────
ClawOps sends:
   1. Installation link
   2. Public key (embedded in skill)
   3. Master Token (via secure channel)
   4. SOUL.md template
   5. USE_CASES folder

Step 3: Client Installs Skill
────────────────────────────────
Client$ cd ~/.openclaw/skills
Client$ git clone https://github.com/DoozieSoftware/claw-ops-security.git
Client$ cd clawops-security
Client$ npm install
Client$ # Configure config.yaml with paths

Step 4: Client Applies Master Token
────────────────────────────────
Client$ python3 scripts/token_validator.py --set-master \
    --token "eyJjbGllbnQiOiJhY21l..."

⬇️ Token verified (offline!) and stored securely

Step 5: System Locks
────────────────────────────────
Client$ python3 scripts/immutability_enforcer.py --lock

⬇️ Filesystem locked:
   🔒 Core (Master only)
   🔐 Configs (Token required)
   🔓 Memory/Context (Always mutable!)

Step 6: System Live!
────────────────────────────────
Bot is now running with:
   ✅ Token verification (offline)
   ✅ Immutability enforced
   ✅ SOUL validation on every action
   ✅ Full audit logging
```

## Emergency Procedures

### Lost Master Token (Client Side)

```
Client Contact: ops@dooziesoft.com

ClawOps:
1. Verify client identity (email, domain)
2. Generate NEW master token
3. Send via encrypted channel
4. Client applies: token_validator.py --set-master --token [NEW_TOKEN]
```

### Integrity Violation Detected

```
System detects: Unauthorized file change
1. Alert sent to: ops@dooziesoft.com
2. Client notified via configured channel
3. Investigation required
4. Possible rollback or redeployment
```

### Emergency Unlock (ClawOps)

```
If client locked themselves out:
1. Client contacts ClawOps
2. ClawOps verifies identity
3. ClawOps generates emergency token (short expiry: 5 min)
4. Client unlocks, fixes issue, relocks
```

## Integration Points

### OpenClaw Hooks

This skill integrates with OpenClaw via:

| Hook | Purpose |
|------|---------|
| `pre-action` | Validate every action against SOUL |
| `post-action` | Log action to audit trail |
| `on-startup` | Enforce immutability |
| `on-shutdown` | Preserve logs |

### Skills Calling This Skill

```javascript
// In another skill
const { validateAction } = require('../clawops-security/utils/soul_validator');

module.exports = async function mySkillAction(context) {
  // Check permission first
  const soulCheck = await validateAction(
    context.user,
    context.channel,
    'my-skill:action-name',
    context.data
  );
  
  if (!soulCheck.allowed) {
    throw new Error(`Action blocked by SOUL: ${soulCheck.errors.join(', ')}`);
  }
  
  // Continue with action...
};
```

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Token verification fails | Check system clock (tokens are time-sensitive) |
| Can't unlock | Verify token hasn't expired |
| Files not locking | Run as root |
| Memory not writable | Check permissions on /root/.openclaw/memory |

## Security Considerations

1. **Public Key Protection** — Client has public key only; private key never leaves ClawOps
2. **Token Expiry** — Client tokens expire; master tokens are long-lived but single-use for unlock
3. **Offline Verification** — No network calls needed for token verification
4. **Audit Trail** — Every action logged, tamper-evident
5. **Memory Mutable** — Agent brain always writable (can't lock that!)

## Support

- ClawOps Ops: ops@dooziesoft.com
- Emergency: security@dooziesoft.com
- Docs: https://docs.clawops.ai/skills/security
