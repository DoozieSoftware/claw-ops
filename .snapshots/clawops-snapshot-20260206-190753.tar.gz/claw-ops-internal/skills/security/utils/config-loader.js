/**
 * Config Loader — Load YAML config in Node.js
 * 
 * Simple YAML parser for config files.
 * For production, use 'js-yaml' library.
 */

const fs = require('fs');
const path = require('path');

/**
 * Simple YAML parser (subset)
 */
function parseYAML(content) {
    const result = {};
    let currentSection = null;
    let currentSubSection = null;
    
    const lines = content.split('\n');
    
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        
        // Skip empty lines and comments
        if (!line || line.startsWith('#')) continue;
        
        // Detect indentation level
        const indent = line.search(/\S/);
        const isSection = indent === 0 && line.endsWith(':');
        const isSubSection = indent === 2 && line.endsWith(':');
        
        // Parse key-value
        if (line.includes(':')) {
            const colonIndex = line.indexOf(':');
            const key = line.substring(0, colonIndex).trim();
            let value = line.substring(colonIndex + 1).trim();
            
            // Remove quotes
            if ((value.startsWith('"') && value.endsWith('"')) ||
                (value.startsWith("'") && value.endsWith("'"))) {
                value = value.slice(1, -1);
            }
            
            // Handle special values
            if (value === 'true') value = true;
            if (value === 'false') value = false;
            if (value === 'null' || value === '~') value = null;
            
            // Number
            if (/^\d+$/.test(value)) value = parseInt(value, 10);
            if (/^\d+\.\d+$/.test(value)) value = parseFloat(value, 10);
            
            // Array
            if (value.startsWith('[') && value.endsWith(']')) {
                const arrayContent = value.slice(1, -1).trim();
                if (arrayContent) {
                    value = arrayContent.split(',').map(v => {
                        let item = v.trim();
                        if ((item.startsWith('"') && item.endsWith('"')) ||
                            (item.startsWith("'") && item.endsWith("'"))) {
                            item = item.slice(1, -1);
                        }
                        return item;
                    });
                } else {
                    value = [];
                }
            }
            
            // Set value
            if (indent === 0) {
                currentSection = key;
                currentSubSection = null;
                result[key] = value;
            } else if (indent === 2) {
                if (currentSection) {
                    if (!result[currentSection]) result[currentSection] = {};
                    currentSubSection = key;
                    result[currentSection][key] = value;
                }
            } else if (indent === 4) {
                if (currentSection && currentSubSection) {
                    if (!result[currentSection][currentSubSection]) {
                        result[currentSection][currentSubSection] = {};
                    }
                    result[currentSection][currentSubSection][key] = value;
                }
            } else {
                if (currentSection) {
                    result[currentSection][key] = value;
                }
            }
        }
    }
    
    return result;
}

/**
 * Load config from YAML file
 */
function loadConfig(configPath) {
    // Try to load with js-yaml if available
    try {
        const yaml = require('js-yaml');
        const content = fs.readFileSync(configPath, 'utf8');
        return yaml.load(content);
    } catch (e) {
        // Fallback to simple parser
    }
    
    // Simple parser fallback
    if (fs.existsSync(configPath)) {
        const content = fs.readFileSync(configPath, 'utf8');
        return parseYAML(content);
    }
    
    return {};
}

/**
 * Main export
 */
module.exports = function(configPath) {
    return loadConfig(configPath || './config.yaml');
};
