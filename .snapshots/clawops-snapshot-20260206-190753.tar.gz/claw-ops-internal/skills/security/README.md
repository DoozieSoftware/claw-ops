# ClawOps Security Skill

**Version:** 1.0.0  
**Category:** Security  
**Author:** DoozieSoftware

---

## Quick Start

### 1. Install on Client's OpenClaw

```bash
# SSH into client's OpenClaw server
ssh root@client-server

# Navigate to OpenClaw skills directory
cd ~/.openclaw/skills

# Clone the security skill
git clone https://github.com/DoozieSoftware/claw-ops-security.git clawops-security
cd clawops-security

# Install dependencies
npm install
```

### 2. Configure

```bash
# Edit config.yaml
nano config.yaml

# Set these values:
client:
  id: "acme-corp"
  name: "Acme Corporation"
  email: "admin@acme.com"

soul:
  path: "/root/.openclaw/clients/acme-corp/SOUL.md"
  use_case_path: "/root/.openclaw/clients/acme-corp/USE_CASES"

# Add ClawOps public key (get from ClawOps after onboarding)
tokens:
  clawops_public_key: |
    -----BEGIN PUBLIC KEY-----
    [PASTE PUBLIC KEY HERE]
    -----END PUBLIC KEY-----
```

### 3. Apply Master Token

```bash
# Get token from ClawOps (via secure channel)
# Run:
python3 scripts/token_validator.py --set-master --token "eyJ..."
```

### 4. Lock System

```bash
python3 scripts/immutability_enforcer.py --lock
```

### 5. Verify

```bash
# Check status
python3 scripts/immutability_enforcer.py --status

# Verify integrity
python3 scripts/immutability_enforcer.py --verify
```

---

## File Structure

```
clawops-security/
├── SKILL.md              ← You are here
├── skill.yaml            ← Skill manifest
├── config.yaml           ← Client configuration (EDIT THIS!)
├── public_key.pem        ← ClawOps public key (auto-generated or paste)
├── package.json          ← Node.js dependencies
├── hooks/
│   ├── pre-action.js     ← Runs before every action
│   └── post-action.js    ← Runs after every action
├── scripts/
│   ├── token_validator.py     ← Token verification (offline!)
│   └── immutability_enforcer.py ← Filesystem lockdown
└── utils/
    └── config-loader.js  ← YAML config loader
```

---

## How It Works

```
┌─────────────────────────────────────────────────────────────────┐
│  CLIENT'S OPENCLAW INSTANCE                                     │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │ clawops-security Skill                                    │  │
│  │                                                           │  │
│  │  ┌─────────────────────────────────────────────────────┐   │  │
│  │  │ Pre-Action Hook (hooks/pre-action.js)            │   │  │
│  │  │                                                     │   │  │
│  │  │ 1. User triggers action                            │   │  │
│  │  │ 2. Hook intercepts action                          │   │  │
│  │  │ 3. Loads SOUL.md                                  │   │  │
│  │  │ 4. Validates: Channel → User → Action → Time      │   │  │
│  │  │ 5. If allowed → Continue                           │   │  │
│  │  │    If blocked → Return error                      │   │  │
│  │  └─────────────────────────────────────────────────────┘   │  │
│  │                                                           │  │
│  │  ┌─────────────────────────────────────────────────────┐   │  │
│  │  │ Token Validator (scripts/token_validator.py)        │   │  │
│  │  │                                                     │   │  │
│  │  │ - Verifies tokens using ClawOps public key         │   │  │
│  │  │ - Works 100% offline (no network calls!)            │   │  │
│  │  │ - Stores token hash locally                         │   │  │
│  │  └─────────────────────────────────────────────────────┘   │  │
│  │                                                           │  │
│  │  ┌─────────────────────────────────────────────────────┐   │  │
│  │  │ Immutability Enforcer (scripts/immutability...)   │   │  │
│  │  │                                                     │   │  │
│  │  │ - Locks filesystem on startup                       │   │  │
│  │  │ - Unlocks only with valid master token             │   │  │
│  │  │ - Records checksums for integrity verification     │   │  │
│  │  │ - Leaves memory/context always mutable!            │   │  │
│  │  └─────────────────────────────────────────────────────┘   │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Token Verification (Offline!)

```
┌──────────────────┐                    ┌──────────────────┐
│  CLAWOPS (You)   │                    │   CLIENT SYSTEM  │
│                  │                    │                  │
│  Has PRIVATE KEY │                    │  Has PUBLIC KEY  │
│        ↓         │                    │        ↑         │
│  Signs tokens    │  Token (via email) │  Verifies token  │
│        ↓         │      ────────►     │        ↓         │
│  Sends to client │                    │  Allows action!  │
└──────────────────┘                    └──────────────────┘
                                              ↑
                                         No network call!
```

**Why this is secure:**
1. Only ClawOps has the private key
2. Client has only the public key (can't forge tokens)
3. Tokens are cryptographically signed
4. Verification works offline (no man-in-the-middle)
5. Master token never expires (but single-use for unlock)

---

## Commands Reference

### Token Validator

```bash
# Verify a token
python3 scripts/token_validator.py --verify "eyJ..."

# Set master token (run once after installation)
python3 scripts/token_validator.py --set-master "eyJ..."

# Check if token matches stored master
python3 scripts/token_validator.py --check-master "eyJ..."

# Show token status
python3 scripts/token_validator.py --status
```

### Immutability Enforcer

```bash
# Lock filesystem
python3 scripts/immutability_enforcer.py --lock

# Unlock for editing (requires master token)
python3 scripts/immutability_enforcer.py --unlock --token "eyJ..."

# Relock after editing
python3 scripts/immutability_enforcer.py --relock

# Check status
python3 scripts/immutability_enforcer.py --status

# Verify integrity
python3 scripts/immutability_enforcer.py --verify

# Emergency relock (force)
python3 scripts/immutability_enforcer.py --force-relock
```

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Token verification fails | Check system clock (tokens are time-sensitive) |
| Can't unlock | Verify token hasn't expired |
| Files not locking | Run scripts as root |
| Memory not writable | Check permissions on /root/.openclaw/memory |
| SOUL not found | Verify soul.path in config.yaml |

### Debug Commands

```bash
# Check if skill is loaded
cd ~/.openclaw && cat openclaw.log | grep security

# Check token status
python3 scripts/token_validator.py --status

# Check immutability status
python3 scripts/immutability_enforcer.py --status

# Verify integrity
python3 scripts/immutability_enforcer.py --verify

# View audit logs
tail -100 /root/.openclaw/logs/security-audit.jsonl
```

---

## Support

- **ClawOps Ops:** ops@dooziesoft.com
- **Emergency:** security@dooziesoft.com
- **Documentation:** https://docs.clawops.ai/skills/security
