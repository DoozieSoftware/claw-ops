/**
 * Pre-Action Hook — SOUL Validation Before Every Action
 * 
 * This hook runs BEFORE every action in OpenClaw.
 * It validates the action against SOUL.md and blocks unauthorized actions.
 * 
 * Usage: Place this file in hooks/ directory of the skill
 */

const fs = require('fs');
const path = require('path');

// Load configuration
const skillDir = path.dirname(__filename).replace('/hooks', '');
const configPath = path.join(skillDir, 'config.yaml');
const config = require('./config-loader')(configPath);

// Paths
const soulPath = config.soul?.path || '/root/.openclaw/clients/CLIENT/SOUL.md';
const useCasePath = config.soul?.use_case_path || '/root/.openclaw/clients/CLIENT/USE_CASES';

// Cache
let soulCache = null;
let soulCacheTime = 0;
const CACHE_TTL = (config.soul?.validation?.cache_ttl_minutes || 5) * 60 * 1000;

/**
 * Load and cache SOUL configuration
 */
function loadSoul() {
    const now = Date.now();
    
    // Return cached if valid
    if (soulCache && (now - soulCacheTime) < CACHE_TTL) {
        return soulCache;
    }
    
    // Load SOUL
    if (!fs.existsSync(soulPath)) {
        console.error(`[Security] SOUL not found: ${soulPath}`);
        return null;
    }
    
    try {
        const soulContent = fs.readFileSync(soulPath, 'utf8');
        soulCache = parseSoul(soulContent);
        soulCacheTime = now;
        return soulCache;
    } catch (e) {
        console.error(`[Security] Failed to load SOUL: ${e.message}`);
        return null;
    }
}

/**
 * Parse SOUL markdown to extract rules
 */
function parseSoul(content) {
    const soul = {
        allowedChannels: [],
        blockedChannels: [],
        allowedUsers: [],
        blockedUsers: [],
        allowedActions: [],
        blockedActions: [],
        allowedUseCases: [],
        timeBoundaries: {
            active: '09:00-19:00',
            timezone: 'IST'
        },
        dataLimits: {
            maxAttachmentSize: 10 * 1024 * 1024  // 10MB default
        }
    };
    
    // Parse simple patterns (in production, use proper markdown parser)
    const lines = content.split('\n');
    
    for (const line of lines) {
        const trimmed = line.trim();
        
        // Channels
        if (trimmed.startsWith('✅ ALLOWED') || trimmed.startsWith('ALLOWED:')) {
            const channels = trimmed.split(':')[1]?.split(',').map(c => c.trim()) || [];
            soul.allowedChannels.push(...channels);
        }
        if (trimmed.startsWith('❌ BLOCKED') || trimmed.startsWith('BLOCKED:')) {
            const channels = trimmed.split(':')[1]?.split(',').map(c => c.trim()) || [];
            soul.blockedChannels.push(...channels);
        }
        
        // Actions
        if (trimmed.startsWith('- `') && soul.allowedActions.length === 0) {
            const action = trimmed.replace(/^- `/, '').replace('`', '').split('`')[0].trim();
            if (action && !action.includes(':')) {
                soul.allowedActions.push(action);
            }
        }
    }
    
    // Try to find action blocks
    const actionBlockMatch = content.match(/Allowed Actions\s*\n\s*```\s*([\s\S]*?)```/);
    if (actionBlockMatch) {
        soul.allowedActions = actionBlockMatch[1]
            .split('\n')
            .map(l => l.trim().replace(/^- /, ''))
            .filter(l => l)
            .map(l => l.replace(/`/g, '').split(' ')[0]);
    }
    
    return soul;
}

/**
 * Check if channel is allowed
 */
function checkChannel(soul, channel) {
    if (soul.blockedChannels.includes('ALL')) {
        return { allowed: false, reason: 'ALL_CHANNELS_BLOCKED' };
    }
    
    if (soul.blockedChannels.includes(channel)) {
        return { allowed: false, reason: 'CHANNEL_BLOCKED', channel };
    }
    
    if (soul.allowedChannels.length > 0 && !soul.allowedChannels.includes(channel)) {
        return { allowed: false, reason: 'CHANNEL_NOT_ALLOWED', channel };
    }
    
    return { allowed: true };
}

/**
 * Check if user is allowed
 */
function checkUser(soul, user) {
    if (soul.blockedUsers.includes(user)) {
        return { allowed: false, reason: 'USER_BLOCKED', user };
    }
    
    if (soul.allowedUsers.length > 0 && !soul.allowedUsers.includes(user)) {
        return { allowed: false, reason: 'USER_NOT_ALLOWED', user };
    }
    
    return { allowed: true };
}

/**
 * Check if action is allowed
 */
function checkAction(soul, action) {
    // Check blocked actions first
    if (soul.blockedActions.includes('ALL')) {
        return { allowed: false, reason: 'ALL_ACTIONS_BLOCKED' };
    }
    
    if (soul.blockedActions.includes(action)) {
        return { allowed: false, reason: 'ACTION_BLOCKED', action };
    }
    
    // Check if action is in allowed list
    if (soul.allowedActions.length > 0 && !soul.allowedActions.includes(action)) {
        return { allowed: false, reason: 'ACTION_NOT_ALLOWED', action };
    }
    
    return { allowed: true };
}

/**
 * Check time boundaries
 */
function checkTime(soul) {
    const now = new Date();
    const [startStr, endStr] = soul.timeBoundaries.active.split('-');
    const currentHour = now.getHours();
    
    const startHour = parseInt(startStr.split(':')[0]);
    const endHour = parseInt(endStr.split(':')[0]);
    
    if (currentHour < startHour || currentHour >= endHour) {
        return { 
            allowed: false, 
            reason: 'OUTSIDE_ACTIVE_HOURS',
            currentHour,
            activeRange: `${startHour}:00-${endHour}:00`
        };
    }
    
    return { allowed: true };
}

/**
 * Check data limits
 */
function checkData(soul, data) {
    if (!data) {
        return { allowed: true };
    }
    
    // Check attachment size
    if (data.attachmentSize && data.attachmentSize > soul.dataLimits.maxAttachmentSize) {
        return { 
            allowed: false, 
            reason: 'ATTACHMENT_TOO_LARGE',
            size: data.attachmentSize,
            maxSize: soul.dataLimits.maxAttachmentSize
        };
    }
    
    return { allowed: true };
}

/**
 * Main validation function
 */
async function validateAction(context) {
    const { user, channel, action, data } = context;
    
    // Load SOUL
    const soul = loadSoul();
    
    if (!soul) {
        console.error('[Security] SOUL not loaded, blocking action');
        return {
            allowed: false,
            reason: 'SOUL_NOT_LOADED',
            errors: ['Security configuration not available']
        };
    }
    
    const errors = [];
    
    // 1. Check channel
    const channelResult = checkChannel(soul, channel);
    if (!channelResult.allowed) {
        errors.push(`${channelResult.reason}: ${channelResult.channel || 'N/A'}`);
    }
    
    // 2. Check user
    const userResult = checkUser(soul, user);
    if (!userResult.allowed) {
        errors.push(`${userResult.reason}: ${userResult.user || 'N/A'}`);
    }
    
    // 3. Check action
    const actionResult = checkAction(soul, action);
    if (!actionResult.allowed) {
        errors.push(`${actionResult.reason}: ${actionResult.action || 'N/A'}`);
    }
    
    // 4. Check time (only for write actions)
    if (action.startsWith('write:') || action.startsWith('send:')) {
        const timeResult = checkTime(soul);
        if (!timeResult.allowed) {
            errors.push(`${timeResult.reason}: ${timeResult.currentHour} not in ${timeResult.activeRange}`);
        }
    }
    
    // 5. Check data
    const dataResult = checkData(soul, data);
    if (!dataResult.allowed) {
        errors.push(`${dataResult.reason}`);
    }
    
    // Return result
    if (errors.length > 0) {
        // Log violation
        logViolation({
            timestamp: new Date().toISOString(),
            user,
            channel,
            action,
            allowed: false,
            errors
        });
        
        return {
            allowed: false,
            reason: 'SOUL_VIOLATION',
            errors
        };
    }
    
    // Allow action
    return {
        allowed: true,
        reason: 'VALIDATED'
    };
}

/**
 * Log SOUL violations
 */
function logViolation(entry) {
    const logPath = config.audit?.path || '/root/.openclaw/logs/security-audit.jsonl';
    
    try {
        const logLine = JSON.stringify({
            ...entry,
            event: 'soul_violation'
        }) + '\n';
        
        fs.appendFileSync(logPath, logLine);
    } catch (e) {
        console.error(`[Security] Failed to log violation: ${e.message}`);
    }
}

/**
 * Hook registration
 */
module.exports = {
    name: 'pre-action',
    handler: async function(context) {
        // Skip if validation disabled
        if (!config.soul?.validation?.strict_mode) {
            return context;
        }
        
        // Validate action
        const result = await validateAction(context);
        
        if (!result.allowed) {
            // Block action
            console.log(`[Security] BLOCKED: ${context.action} by ${context.user}`);
            console.log(`[Security] Reasons: ${result.errors.join(', ')}`);
            
            // Return blocked response
            return {
                ...context,
                _blocked: true,
                _blockReason: result.reason,
                _blockErrors: result.errors,
                _response: {
                    text: `🚫 Action blocked by SOUL security policy.\n\nReasons:\n${result.errors.map(e => `- ${e}`).join('\n')}`
                }
            };
        }
        
        // Allow action
        return context;
    }
};
