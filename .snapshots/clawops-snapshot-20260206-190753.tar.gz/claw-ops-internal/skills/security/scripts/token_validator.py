#!/usr/bin/env python3
"""
Token Validator — Offline Token Verification for Client
======================================================

This script runs on CLIENT's OpenClaw instance.
It verifies tokens using ClawOps' public key (works offline!).

Usage:
    python3 token_validator.py --verify --token "eyJ..."
    python3 token_validator.py --set-master --token "eyJ..."
    python3 token_validator.py --status
"""

import argparse
import base64
import hashlib
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path


class TokenValidator:
    """
    Validates ClawOps-signed tokens using public key cryptography.
    
    Token Format (JWT-like):
    header.payload.signature
    
    Where:
    - header: Base64-encoded JSON with alg, typ
    - payload: Base64-encoded JSON with client, type, expiry
    - signature: Base64-encoded Ed25519 signature
    """
    
    def __init__(self, config_path: str = None):
        # Find config.yaml
        if config_path:
            self.config_path = Path(config_path)
        else:
            # Look in skill directory
            skill_dir = Path(__file__).parent.parent
            self.config_path = skill_dir / 'config.yaml'
        
        self.config = self._load_config()
        
        # Find public key
        self.public_key = self._load_public_key()
        
        # Token storage
        self.token_storage = Path(self.config.get('tokens', {}).get(
            'token_storage', '/root/.openclaw/.security/tokens.json'
        ))
        self.token_storage.parent.mkdir(parents=True, exist_ok=True)
        
        if not self.token_storage.exists():
            self.token_storage.write_text('{}')
    
    def _load_config(self) -> dict:
        """Load configuration from config.yaml."""
        if self.config_path.exists():
            with open(self.config_path) as f:
                return json.load(f)
        return {}
    
    def _load_public_key(self):
        """Load ClawOps public key for verification."""
        # First try config
        key_config = self.config.get('tokens', {}).get('clawops_public_key', '')
        
        if key_config and 'BEGIN PUBLIC KEY' in key_config:
            return key_config
        
        # Fallback to public_key.pem file
        pem_path = Path(__file__).parent.parent / 'public_key.pem'
        if pem_path.exists():
            return pem_path.read_text()
        
        raise ValueError(
            "ClawOps public key not found. "
            "Add 'clawops_public_key' to config.yaml or place public_key.pem in skill directory."
        )
    
    def _base64url_decode(self, data: str) -> bytes:
        """Decode base64url without padding."""
        padding = 4 - len(data) % 4
        if padding != 4:
            data += '=' * padding
        return base64.urlsafe_b64decode(data)
    
    def _base64url_encode(self, data: bytes) -> str:
        """Encode to base64url without padding."""
        return base64.urlsafe_b64encode(data).rstrip(b'=').decode()
    
    def _parse_token(self, token: str) -> dict:
        """
        Parse JWT-like token.
        
        Returns:
            dict with: header, payload, signature, raw
        """
        parts = token.split('.')
        if len(parts) != 3:
            raise ValueError(f"Invalid token format: expected 3 parts, got {len(parts)}")
        
        header_b64, payload_b64, signature_b64 = parts
        
        try:
            header = json.loads(self._base64url_decode(header_b64))
            payload = json.loads(self._base64url_decode(payload_b64))
            signature = self._base64url_decode(signature_b64)
        except Exception as e:
            raise ValueError(f"Failed to decode token: {e}")
        
        return {
            'header': header,
            'payload': payload,
            'signature': signature,
            'raw': f"{header_b64}.{payload_b64}"
        }
    
    def _verify_signature(self, token_data: str, signature: bytes, public_key: str) -> bool:
        """
        Verify Ed25519 signature.
        
        In production, use proper Ed25519 library. For now, simulate with SHA256.
        """
        try:
            # Try Ed25519 first (requires cryptography library)
            from cryptography.hazmat.primitives.asymmetric import ed25519
            from cryptography.hazmat.primitives import serialization
            
            # Load public key
            key = serialization.load_pem_public_key(public_key.encode())
            
            # Verify
            key.verify(signature, token_data.encode())
            return True
            
        except ImportError:
            # Fallback: SHA256 HMAC (less secure but works without cryptography lib)
            # In production, ALWAYS use Ed25519
            import hmac
            
            key_bytes = hashlib.sha256(public_key.encode()).digest()
            expected_sig = hmac.new(key_bytes, token_data.encode(), hashlib.sha256).digest()
            
            return hmac.compare_digest(signature, expected_sig[:len(signature)])
    
    def verify(self, token: str, verbose: bool = True) -> dict:
        """
        Verify a token (offline!).
        
        Returns:
            dict with: valid, client, token_type, expiry, error
        """
        try:
            parsed = self._parse_token(token)
            payload = parsed['payload']
            
            # Verify signature
            if not self._verify_signature(parsed['raw'], parsed['signature'], self.public_key):
                return {
                    'valid': False,
                    'error': 'INVALID_SIGNATURE',
                    'details': 'Token signature verification failed'
                }
            
            # Check expiry (master tokens use special value)
            expiry = payload.get('expires_at', 0)
            if expiry != 'never' and expiry != 99999999999:
                if datetime.fromtimestamp(expiry) < datetime.utcnow():
                    return {
                        'valid': False,
                        'error': 'TOKEN_EXPIRED',
                        'expired_at': datetime.fromtimestamp(expiry).isoformat()
                    }
            
            return {
                'valid': True,
                'client': payload.get('client'),
                'token_type': payload.get('type'),
                'expires_at': expiry,
                'issued_at': datetime.fromtimestamp(payload.get('iat', 0)).isoformat(),
                'is_master': payload.get('type') == 'master'
            }
            
        except Exception as e:
            return {
                'valid': False,
                'error': 'PARSE_ERROR',
                'details': str(e)
            }
    
    def set_master_token(self, token: str, verbose: bool = True) -> bool:
        """
        Set the master token for this client.
        
        Stores the token hash locally for quick verification.
        """
        # Verify token first
        result = self.verify(token)
        
        if not result['valid']:
            if verbose:
                print(f"❌ Token verification failed: {result['error']}")
                if 'details' in result:
                    print(f"   {result['details']}")
            return False
        
        if not result['is_master']:
            if verbose:
                print(f"⚠️  Token is not a master token (type: {result['token_type']})")
            return False
        
        # Store token hash
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        
        with open(self.token_storage) as f:
            tokens = json.load(f)
        
        tokens['master'] = {
            'hash': token_hash,
            'client': result['client'],
            'set_at': datetime.utcnow().isoformat(),
            'verified': True
        }
        
        with open(self.token_storage, 'w') as f:
            json.dump(tokens, f, indent=2)
        
        # Set permissions restrictive
        os.chmod(self.token_storage, 0o600)
        
        if verbose:
            print(f"✅ Master token set for client: {result['client']}")
            print(f"   Token hash stored securely")
        
        return True
    
    def check_master_token(self, token: str, verbose: bool = True) -> bool:
        """
        Check if provided token matches stored master token.
        """
        with open(self.token_storage) as f:
            tokens = json.load(f)
        
        if 'master' not in tokens:
            if verbose:
                print("❌ No master token configured")
            return False
        
        stored_hash = tokens['master']['hash']
        input_hash = hashlib.sha256(token.encode()).hexdigest()
        
        return stored_hash == input_hash
    
    def status(self, verbose: bool = True) -> dict:
        """Show token status."""
        with open(self.token_storage) as f:
            tokens = json.load(f)
        
        status = {
            'master_configured': 'master' in tokens,
            'master_client': tokens.get('master', {}).get('client'),
            'master_set_at': tokens.get('master', {}).get('set_at'),
            'token_storage': str(self.token_storage)
        }
        
        if verbose:
            print(f"\n{'='*50}")
            print(f"  TOKEN STATUS")
            print(f"{'='*50}")
            print(f"Master Token: {'✅ Configured' if status['master_configured'] else '❌ Not configured'}")
            if status['master_client']:
                print(f"Client: {status['master_client']}")
                print(f"Set At: {status['master_set_at']}")
            print(f"{'='*50}\n")
        
        return status
    
    def list_client_tokens(self, verbose: bool = True) -> list:
        """List active client tokens."""
        with open(self.token_storage) as f:
            tokens = json.load(f)
        
        client_tokens = tokens.get('client_tokens', [])
        
        if verbose:
            print(f"\nActive Client Tokens: {len(client_tokens)}")
            for token in client_tokens:
                print(f"  - {token.get('client')}: {token.get('type')} (expires: {token.get('expires_at')})")
        
        return client_tokens


def main():
    parser = argparse.ArgumentParser(
        description='Token Validator — Offline token verification for ClawOps clients'
    )
    
    parser.add_argument(
        '--verify',
        type=str,
        metavar='TOKEN',
        help='Verify a token (offline)'
    )
    
    parser.add_argument(
        '--set-master',
        type=str,
        metavar='TOKEN',
        help='Set master token for this client'
    )
    
    parser.add_argument(
        '--check-master',
        type=str,
        metavar='TOKEN',
        help='Check if token matches stored master'
    )
    
    parser.add_argument(
        '--status',
        action='store_true',
        help='Show token status'
    )
    
    parser.add_argument(
        '--config',
        type=str,
        help='Path to config.yaml'
    )
    
    args = parser.parse_args()
    
    validator = TokenValidator(args.config)
    
    if args.verify:
        result = validator.verify(args.verify)
        
        if result['valid']:
            print(f"✅ Token VALID")
            print(f"   Client: {result['client']}")
            print(f"   Type: {result['token_type']}")
            print(f"   Master: {result['is_master']}")
            print(f"   Expires: {'Never' if result['expires_at'] in ['never', 99999999999] else result['expires_at']}")
            exit(0)
        else:
            print(f"❌ Token INVALID: {result['error']}")
            if 'details' in result:
                print(f"   {result['details']}")
            exit(1)
    
    elif args.set_master:
        success = validator.set_master_token(args.set_master)
        exit(0 if success else 1)
    
    elif args.check_master:
        success = validator.check_master_token(args.check_master)
        print(f"✅ Token matches" if success else "❌ Token does not match")
        exit(0 if success else 1)
    
    elif args.status:
        validator.status()
    
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
