#!/usr/bin/env python3
"""
Immutability Enforcer — Filesystem Lockdown for Client
=======================================================

This script runs on CLIENT's OpenClaw instance.
It enforces immutability based on config.yaml settings.

Usage:
    python3 immutability_enforcer.py --lock
    python3 immutability_enforcer.py --unlock --token "eyJ..."
    python3 immutability_enforcer.py --relock
    python3 immutability_enforcer.py --status
    python3 immutability_enforcer.py --verify
"""

import argparse
import hashlib
import json
import os
import stat
import sys
import time
from datetime import datetime
from pathlib import Path


class ImmutabilityEnforcer:
    """
    Enforces filesystem immutability based on 4-layer security model.
    
    Layers:
    1. IMMUTABLE_CORE (Master Token only)
    2. LOCKED_PATHS (Client or Master Token)
    3. ALWAYS_MUTABLE (Memory/Brain - NEVER lock!)
    4. APPEND_ONLY (Logs)
    """
    
    def __init__(self, config_path: str = None):
        # Find config.yaml
        if config_path:
            self.config_path = Path(config_path)
        else:
            skill_dir = Path(__file__).parent.parent
            self.config_path = skill_dir / 'config.yaml'
        
        self.config = self._load_config()
        
        # Paths from config
        self.settings = self.config.get('immutability', {})
        
        self.immutable_core = self.settings.get('immutable_core', [
            '/root/.openclaw/core',
            '/root/.openclaw/skills',
            '/root/.openclaw/node_modules'
        ])
        
        self.locked_paths = self.settings.get('locked_paths', [
            '/root/.openclaw/config',
            '/root/.openclaw/clients'
        ])
        
        self.always_mutable = self.settings.get('always_mutable', [
            '/root/.openclaw/memory',
            '/root/.openclaw/data',
            '/root/.openclaw/context'
        ])
        
        self.append_only = self.settings.get('append_only', [
            '/root/.openclaw/logs'
        ])
        
        # Status file
        self.status_file = Path('/root/.openclaw/.security/immutability_status.json')
        self.status_file.parent.mkdir(parents=True, exist_ok=True)
        
        # Token validator
        token_script = Path(__file__).parent / 'token_validator.py'
        sys.path.insert(0, str(token_script.parent))
        
        # Import token validator
        try:
            import token_validator
            self.token_validator = token_validator.TokenValidator(str(self.config_path))
        except Exception:
            self.token_validator = None
    
    def _load_config(self) -> dict:
        """Load configuration from config.yaml."""
        if self.config_path.exists():
            with open(self.config_path) as f:
                return json.load(f)
        return {}
    
    def _calculate_checksum(self, file_path: Path) -> str:
        """Calculate SHA256 checksum of a file."""
        if not file_path.exists() or not file_path.is_file():
            return ''
        sha256 = hashlib.sha256()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                sha256.update(chunk)
        return sha256.hexdigest()
    
    def _get_all_files(self, path: str) -> list:
        """Get all files in a directory recursively."""
        p = Path(path)
        if p.exists() and p.is_dir():
            return [f for f in p.rglob('*') if f.is_file()]
        return []
    
    def _set_permissions(self, paths: list, writable: bool, verbose: bool = True):
        """Set permissions for a list of paths."""
        results = {'success': 0, 'failed': 0, 'errors': []}
        
        for path_str in paths:
            path = Path(path_str)
            if not path.exists():
                # Create directory if it doesn't exist
                try:
                    path.mkdir(parents=True, exist_ok=True)
                    results['success'] += 1
                    if verbose:
                        print(f"  📁 Created: {path}")
                except Exception as e:
                    results['failed'] += 1
                    results['errors'].append(f"{path}: {e}")
                continue
            
            try:
                for item in path.rglob('*'):
                    if item.is_file():
                        if writable:
                            os.chmod(item, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)  # 777
                        else:
                            os.chmod(item, stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH)  # 444
                        results['success'] += 1
                    elif item.is_dir():
                        if writable:
                            os.chmod(item, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)  # 777
                        else:
                            os.chmod(item, stat.S_IRWXU)  # 700 for dirs
                if verbose:
                    mode = "🔓 Writable" if writable else "🔒 Read-only"
                    print(f"  {mode}: {path}")
            except Exception as e:
                results['failed'] += 1
                results['errors'].append(f"{path}: {e}")
        
        return results
    
    def lock(self, verbose: bool = True) -> dict:
        """
        Lock the filesystem.
        """
        status = {
            'timestamp': datetime.utcnow().isoformat(),
            'action': 'lock',
            'locked_paths': [],
            'errors': []
        }
        
        if verbose:
            print("🔒 Locking filesystem...")
            print("")
        
        # 1. Lock immutable core (Master Token only)
        if verbose:
            print("  Layer 1: Immutable Core (Master Token only)")
        result = self._set_permissions(self.immutable_core, writable=False, verbose=False)
        status['locked_paths'].extend(self.immutable_core)
        if verbose:
            for path in self.immutable_core:
                print(f"    🔒 {path}")
        
        # 2. Lock config paths (Token required)
        if verbose:
            print("")
            print("  Layer 2: Locked Configs (Token required)")
        for path in self.locked_paths:
            path_obj = Path(path)
            if path_obj.exists():
                try:
                    for item in path_obj.rglob('*'):
                        if item.is_file():
                            os.chmod(item, stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH)  # 444
                    if verbose:
                        print(f"    🔐 {path}")
                    status['locked_paths'].append(path)
                except Exception as e:
                    status['errors'].append(f"{path}: {e}")
        
        # 3. Ensure always mutable paths are writable (AGENT BRAIN!)
        if verbose:
            print("")
            print("  Layer 3: Always Mutable (Agent Brain - NEVER LOCK!)")
        for path in self.always_mutable:
            path_obj = Path(path)
            path_obj.mkdir(parents=True, exist_ok=True)
            try:
                os.chmod(path_obj, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)  # 777
                if verbose:
                    print(f"    🔓 {path} (always mutable!)")
                status['locked_paths'].append(f"{path} (mutable)")
            except Exception as e:
                status['errors'].append(f"{path}: {e}")
        
        # 4. Ensure logs are writable (append-only)
        if verbose:
            print("")
            print("  Layer 4: Append-only Logs")
        for path in self.append_only:
            path_obj = Path(path)
            path_obj.mkdir(parents=True, exist_ok=True)
            try:
                os.chmod(path_obj, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)  # 777
                if verbose:
                    print(f"    📝 {path} (append-only)")
                status['locked_paths'].append(f"{path} (logs)")
            except Exception as e:
                status['errors'].append(f"{path}: {e}")
        
        # 5. Record checksums for protected paths
        checksums = {}
        for path_str in self.immutable_core + self.locked_paths:
            path = Path(path_str)
            if path.exists():
                for item in path.rglob('*'):
                    if item.is_file():
                        checksums[str(item)] = self._calculate_checksum(item)
        
        # Save status
        status_data = {
            'status': 'LOCKED',
            'locked_at': status['timestamp'],
            'checksums': checksums,
            'layers': {
                'immutable_core': self.immutable_core,
                'locked_paths': self.locked_paths,
                'always_mutable': self.always_mutable,
                'append_only': self.append_only
            }
        }
        
        with open(self.status_file, 'w') as f:
            json.dump(status_data, f, indent=2)
        
        if verbose:
            print("")
            print(f"✅ Filesystem LOCKED")
            print(f"   Immutable core: {len(self.immutable_core)} paths")
            print(f"   Locked paths: {len(self.locked_paths)} paths")
            print(f"   Always mutable: {len(self.always_mutable)} paths")
            print(f"   Checksums recorded: {len(checksums)}")
        
        if status['errors']:
            print(f"\n⚠️  Errors:")
            for err in status['errors']:
                print(f"   - {err}")
        
        return status
    
    def unlock(self, token: str, verbose: bool = True) -> bool:
        """
        Unlock filesystem for editing.
        
        Requires valid master token.
        """
        # Verify token
        if self.token_validator:
            result = self.token_validator.verify(token)
            
            if not result['valid']:
                if verbose:
                    print(f"❌ Token verification failed: {result['error']}")
                return False
            
            if not result['is_master']:
                if verbose:
                    print(f"⚠️  Master token required (got: {result['token_type']})")
                return False
        else:
            # Fallback: check against stored master token
            if not self.token_validator.check_master_token(token):
                if verbose:
                    print("❌ Invalid token")
                return False
        
        if verbose:
            print("🔓 Unlocking filesystem...")
            print("")
        
        # Unlock Layer 1 (Immutable Core)
        if verbose:
            print("  Layer 1: Immutable Core")
        for path in self.immutable_core:
            path_obj = Path(path)
            if path_obj.exists():
                for item in path_obj.rglob('*'):
                    if item.is_file():
                        os.chmod(item, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)  # 777
                if verbose:
                    print(f"    🔓 {path} (Master Token)")
        
        # Unlock Layer 2 (Locked Paths)
        if verbose:
            print("")
            print("  Layer 2: Locked Paths")
        for path in self.locked_paths:
            path_obj = Path(path)
            if path_obj.exists():
                for item in path_obj.rglob('*'):
                    if item.is_file():
                        os.chmod(item, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)  # 777
                if verbose:
                    print(f"    🔓 {path}")
        
        # Update status
        with open(self.status_file) as f:
            status_data = json.load(f)
        
        status_data['status'] = 'UNLOCKED'
        status_data['unlocked_at'] = datetime.utcnow().isoformat()
        status_data['unlock_token'] = {
            'client': result.get('client') if self.token_validator else 'unknown',
            'type': 'master'
        }
        
        with open(self.status_file, 'w') as f:
            json.dump(status_data, f, indent=2)
        
        if verbose:
            print("")
            print(f"✅ Filesystem UNLOCKED")
            print(f"   Token type: Master")
            print(f"   ⚠️  EDITS COMPLETE? Run --relock!")
        
        return True
    
    def relock(self, verbose: bool = True) -> dict:
        """
        Relock filesystem after editing.
        """
        with open(self.status_file) as f:
            status_data = json.load(f)
        
        if status_data.get('status') != 'UNLOCKED':
            if verbose:
                print("⚠️  Filesystem is not unlocked")
            return {'action': 'none', 'status': status_data.get('status')}
        
        if verbose:
            print("🔒 Relocking filesystem...")
            print("")
        
        # Relock all protected paths
        for path in self.immutable_core + self.locked_paths:
            path_obj = Path(path)
            if path_obj.exists():
                for item in path_obj.rglob('*'):
                    if item.is_file():
                        os.chmod(item, stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH)  # 444
        
        # Record new checksums
        checksums = {}
        for path_str in self.immutable_core + self.locked_paths:
            path = Path(path_str)
            if path.exists():
                for item in path.rglob('*'):
                    if item.is_file():
                        checksums[str(item)] = self._calculate_checksum(item)
        
        # Update status
        status_data['status'] = 'LOCKED'
        status_data['relocked_at'] = datetime.utcnow().isoformat()
        status_data['checksums'] = checksums
        status_data.pop('unlocked_at', None)
        status_data.pop('unlock_token', None)
        
        with open(self.status_file, 'w') as f:
            json.dump(status_data, f, indent=2)
        
        if verbose:
            print(f"✅ Filesystem RELOCKED")
            print(f"   Checksums updated: {len(checksums)}")
        
        return {'action': 'relock', 'status': 'LOCKED'}
    
    def verify_integrity(self, verbose: bool = True) -> dict:
        """
        Verify integrity against recorded checksums.
        """
        with open(self.status_file) as f:
            status_data = json.load(f)
        
        recorded_checksums = status_data.get('checksums', {})
        
        violations = []
        for file_path, expected_hash in recorded_checksums.items():
            current_hash = self._calculate_checksum(Path(file_path))
            
            if current_hash != expected_hash:
                violations.append({
                    'file': file_path,
                    'status': 'MODIFIED'
                })
        
        result = {
            'status': status_data.get('status', 'UNKNOWN'),
            'verified_at': datetime.utcnow().isoformat(),
            'files_verified': len(recorded_checksums),
            'violations': violations,
            'integrity': 'VALID' if not violations else 'VIOLATED'
        }
        
        if verbose:
            if not violations:
                print("✅ INTEGRITY CHECK PASSED")
                print(f"   Files verified: {len(recorded_checksums)}")
            else:
                print("⚠️  INTEGRITY VIOLATIONS DETECTED!")
                print(f"   Files verified: {len(recorded_checksums)}")
                print(f"   Violations: {len(violations)}")
                for v in violations:
                    print(f"   - {v['file']}: {v['status']}")
        
        return result
    
    def status(self, verbose: bool = True) -> dict:
        """Show current status."""
        if not self.status_file.exists():
            status = {'status': 'NEVER_LOCKED'}
        else:
            with open(self.status_file) as f:
                status = json.load(f)
        
        if verbose:
            print(f"\n{'='*50}")
            print(f"  IMMUTABILITY STATUS")
            print(f"{'='*50}")
            print(f"Status: {status.get('status', 'UNKNOWN')}")
            
            if 'locked_at' in status:
                print(f"Locked at: {status['locked_at'][:19]}")
            if 'unlocked_at' in status:
                print(f"Unlocked at: {status['unlocked_at'][:19]}")
                if 'unlock_token' in status:
                    print(f"Unlock token: {status['unlock_token'].get('type', 'unknown')}")
            if 'relocked_at' in status:
                print(f"Relocked at: {status['relocked_at'][:19]}")
            
            print(f"")
            print(f"Layer 1 (Immutable Core): {len(self.immutable_core)} paths")
            print(f"Layer 2 (Locked Paths): {len(self.locked_paths)} paths")
            print(f"Layer 3 (Always Mutable): {len(self.always_mutable)} paths")
            print(f"Layer 4 (Logs): {len(self.append_only)} paths")
            print(f"")
            print(f"Files protected: {len(status.get('checksums', {}))}")
            print(f"{'='*50}\n")
        
        return status
    
    def force_relock(self, verbose: bool = True):
        """
        Emergency: Force relock without checksum verification.
        """
        if verbose:
            print("🚨 EMERGENCY RELOCK")
            print("")
        
        self.lock(verbose=False)
        
        # Clear any unlock state
        with open(self.status_file) as f:
            status_data = json.load(f)
        
        status_data['force_relocked_at'] = datetime.utcnow().isoformat()
        status_data['emergency'] = True
        
        with open(self.status_file, 'w') as f:
            json.dump(status_data, f, indent=2)
        
        if verbose:
            print("✅ Emergency relock complete")


def main():
    parser = argparse.ArgumentParser(
        description='Immutability Enforcer — Filesystem lockdown for ClawOps clients'
    )
    
    parser.add_argument('--lock', action='store_true', help='Lock filesystem')
    parser.add_argument('--unlock', type=str, metavar='TOKEN', help='Unlock with token')
    parser.add_argument('--relock', action='store_true', help='Relock after editing')
    parser.add_argument('--status', action='store_true', help='Show status')
    parser.add_argument('--verify', action='store_true', help='Verify integrity')
    parser.add_argument('--force-relock', action='store_true', help='Emergency relock')
    parser.add_argument('--config', type=str, help='Path to config.yaml')
    parser.add_argument('--verbose', action='store_true', default=True, help='Verbose output')
    
    args = parser.parse_args()
    
    enforcer = ImmutabilityEnforcer(args.config)
    
    if args.lock:
        enforcer.lock(verbose=args.verbose)
    
    elif args.unlock:
        success = enforcer.unlock(args.unlock, verbose=args.verbose)
        sys.exit(0 if success else 1)
    
    elif args.relock:
        enforcer.relock(verbose=args.verbose)
    
    elif args.verify:
        enforcer.verify_integrity(verbose=args.verbose)
    
    elif args.force_relock:
        enforcer.force_relock(verbose=args.verbose)
    
    elif args.status:
        enforcer.status(verbose=args.verbose)
    
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
