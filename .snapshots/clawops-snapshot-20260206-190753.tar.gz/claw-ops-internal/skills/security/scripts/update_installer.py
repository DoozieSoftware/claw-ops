#!/usr/bin/env python3
"""
Offline Update Installer — For Air-Gapped Client Systems
=======================================================

Installs signed update packages on offline/clawops clients.

Usage:
    python3 update_installer.py --install ./update-v1.1.0/
    python3 update_installer.py --verify ./update-v1.1.0/
    python3 update_installer.py --rollback
    python3 update_installer.py --status
    python3 update_installer.py --list
"""

import argparse
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import tarfile
import tempfile
import yaml
from datetime import datetime
from pathlib import Path


class UpdateInstaller:
    """
    Installs signed update packages on offline client systems.
    
    Security (Offline!):
    1. Verify package signature with CLAWOPS PUBLIC KEY
    2. Verify all file checksums
    3. Backup current state
    4. Apply updates
    5. Verify installation
    6. Keep rollback point
    """
    
    def __init__(self, base_path: str = '/root/.openclaw'):
        self.base_path = Path(base_path)
        
        # Paths
        self.updates_dir = self.base_path / 'updates'
        self.rollback_dir = self.base_path / '.rollback'
        self.backup_dir = self.base_path / '.backup'
        self.registry_file = self.base_path / '.update_registry.yaml'
        self.config_file = self.base_path / '.security/config.yaml'
        
        # Create directories
        self.updates_dir.mkdir(parents=True, exist_ok=True)
        self.rollback_dir.mkdir(parents=True, exist_ok=True)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        
        # Load configuration
        self.config = self._load_config()
        
        # Load registry
        self.registry = self._load_registry()
    
    def _load_config(self) -> dict:
        """Load security configuration."""
        if self.config_file.exists():
            with open(self.config_file) as f:
                return yaml.safe_load(f) or {}
        return {}
    
    def _load_registry(self) -> dict:
        """Load update registry."""
        if self.registry_file.exists():
            with open(self.registry_file) as f:
                return yaml.safe_load(f) or {}
        return {
            'current_version': None,
            'installed_updates': [],
            'rollback_available': False,
            'rollback_version': None
        }
    
    def _save_registry(self):
        """Save update registry."""
        with open(self.registry_file, 'w') as f:
            yaml.dump(self.registry, f)
        # Set restrictive permissions
        os.chmod(self.registry_file, 0o600)
    
    def _get_public_key(self) -> str:
        """Get ClawOps public key from config."""
        key_config = self.config.get('tokens', {}).get('clawops_public_key', '')
        
        if key_config and 'BEGIN PUBLIC KEY' in key_config:
            return key_config
        
        # Check for public key file
        key_paths = [
            self.base_path / '.security/public_key.pem',
            self.base_path / 'security/public_key.pem',
            './public_key.pem'
        ]
        
        for key_path in key_paths:
            if key_path.exists():
                return key_path.read_text()
        
        raise ValueError(
            "ClawOps public key not found. Add 'clawops_public_key' to config.yaml or place public_key.pem in .security/"
        )
    
    def _calculate_checksum(self, file_path: Path) -> str:
        """Calculate SHA256 checksum."""
        sha256 = hashlib.sha256()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                sha256.update(chunk)
        return sha256.hexdigest()
    
    def _verify_signature(self, manifest_content: str, signature: str, public_key: str) -> bool:
        """
        Verify Ed25519 signature with public key.
        
        Offline! No network calls.
        """
        try:
            from cryptography.hazmat.primitives import hashes, serialization
            from cryptography.hazmat.primitives.asymmetric import padding
            from cryptography.hazmat.backends import default_backend
            from cryptography.exceptions import InvalidSignature
            
            # Load public key
            key = serialization.load_pem_public_key(
                public_key.encode(),
                backend=default_backend()
            )
            
            # Verify signature
            key.verify(
                bytes.fromhex(signature),
                manifest_content.encode(),
                padding.PSS(
                    padding.MGF1(hashes.SHA256()),
                    padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            
            return True
            
        except ImportError:
            # Fallback: HMAC verification (less secure)
            key_bytes = hashlib.sha256(public_key.encode()).digest()
            import hmac
            expected = hmac.new(key_bytes, manifest_content.encode(), hashlib.sha256).hexdigest()
            return hmac.compare_digest(signature, expected)
    
    def verify_package(self, package_path: str, verbose: bool = True) -> dict:
        """
        Verify a package before installation.
        
        Checks:
        1. Package exists and has correct structure
        2. Signature is valid
        3. All file checksums match
        """
        path = Path(package_path)
        
        result = {
            'valid': False,
            'version': None,
            'errors': []
        }
        
        if verbose:
            print(f"\n🔍 Verifying package: {path}")
        
        try:
            # 1. Check package structure
            if not path.exists():
                result['errors'].append(f"Package not found: {package_path}")
                return result
            
            # 2. Load manifest
            manifest_path = path / 'manifest.yaml'
            if not manifest_path.exists():
                result['errors'].append("manifest.yaml not found")
                return result
            
            with open(manifest_path) as f:
                manifest = yaml.safe_load(f)
            
            result['version'] = manifest.get('version')
            
            if verbose:
                print(f"   Version: v{manifest.get('version')}")
                print(f"   Files: {manifest.get('file_count')}")
            
            # 3. Verify signature
            sig_path = path / 'signature.yaml'
            if not sig_path.exists():
                result['errors'].append("signature.yaml not found")
                return result
            
            with open(sig_path) as f:
                signature_data = yaml.safe_load(f)
            
            manifest_content = open(manifest_path).read()
            public_key = self._get_public_key()
            
            if not self._verify_signature(
                manifest_content,
                signature_data.get('signature', ''),
                public_key
            ):
                result['errors'].append("INVALID SIGNATURE - Package may be tampered!")
                return result
            
            if verbose:
                print("   ✅ Signature verified")
            
            # 4. Verify all file checksums
            files_path = path / 'files'
            if not files_path.exists():
                result['errors'].append("files/ directory not found")
                return result
            
            manifest_files = manifest.get('files', {})
            errors = []
            
            for rel_path, expected_checksum in manifest_files.items():
                file_path = files_path / rel_path
                
                if not file_path.exists():
                    errors.append(f"Missing file: {rel_path}")
                    continue
                
                actual_checksum = self._calculate_checksum(file_path)
                
                if actual_checksum != expected_checksum:
                    errors.append(f"Checksum mismatch: {rel_path}")
            
            if errors:
                result['errors'].extend(errors)
                return result
            
            if verbose:
                print(f"   ✅ All {len(manifest_files)} files verified")
            
            result['valid'] = True
            result['manifest'] = manifest
            
            return result
            
        except Exception as e:
            result['errors'].append(f"Verification error: {str(e)}")
            return result
    
    def create_rollback_point(self, version: str, verbose: bool = True) -> bool:
        """
        Create a rollback point before updating.
        
        Backs up modified files to .rollback directory.
        """
        if verbose:
            print(f"\n💾 Creating rollback point: v{version}")
        
        try:
            # Create rollback directory
            rollback_path = self.rollback_dir / f'rollback-{version}-{datetime.now().strftime("%Y%m%d-%H%M%S")}'
            rollback_path.mkdir(parents=True, exist_ok=True)
            
            # Find files that will be updated
            updates_dir = self.updates_dir / f'update-{version}'
            
            if not updates_dir.exists():
                if verbose:
                    print("   ⚠️  No updates directory, skipping backup")
                return True
            
            # Copy files to rollback
            files_dir = updates_dir / 'files'
            if files_dir.exists():
                for root, dirs, files in os.walk(files_dir):
                    for file in files:
                        src = Path(root) / file
                        rel = src.relative_to(files_dir)
                        
                        # Copy to rollback
                        dst = rollback_path / rel
                        dst.parent.mkdir(parents=True, exist_ok=True)
                        
                        # Only backup if file exists in current system
                        current_file = self.base_path / rel
                        if current_file.exists():
                            shutil.copy2(current_file, dst)
            
            if verbose:
                print(f"   ✅ Rollback point created: {rollback_path}")
            
            # Update registry
            self.registry['rollback_available'] = True
            self.registry['rollback_version'] = version
            self._save_registry()
            
            return True
            
        except Exception as e:
            if verbose:
                print(f"   ❌ Failed to create rollback: {e}")
            return False
    
    def install(self, package_path: str, verbose: bool = True) -> dict:
        """
        Install an update package.
        
        Steps:
        1. Verify package
        2. Create rollback point
        3. Apply files
        4. Update registry
        """
        result = {
            'success': False,
            'version': None,
            'errors': []
        }
        
        try:
            # 1. Verify package
            verify_result = self.verify_package(package_path, verbose=verbose)
            
            if not verify_result['valid']:
                result['errors'] = verify_result['errors']
                return result
            
            version = verify_result['version']
            result['version'] = version
            
            # 2. Create rollback point
            if not self.create_rollback_point(version, verbose=verbose):
                result['errors'].append("Failed to create rollback point")
                return result
            
            # 3. Apply files
            if verbose:
                print(f"\n📦 Installing update: v{version}")
            
            source_dir = Path(package_path) / 'files'
            
            if not source_dir.exists():
                result['errors'].append("files/ directory not found in package")
                return result
            
            files_installed = 0
            
            for root, dirs, files in os.walk(source_dir):
                for file in files:
                    src = Path(root) / file
                    rel = src.relative_to(source_dir)
                    dst = self.base_path / rel
                    
                    # Create parent directories
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    
                    # Copy file
                    shutil.copy2(src, dst)
                    files_installed += 1
            
            if verbose:
                print(f"   ✅ Installed {files_installed} files")
            
            # 4. Update registry
            self.registry['current_version'] = version
            self.registry['installed_updates'].append({
                'version': version,
                'installed_at': datetime.utcnow().isoformat(),
                'package': str(Path(package_path).absolute())
            })
            self.registry['rollback_available'] = True
            self.registry['rollback_version'] = version
            self._save_registry()
            
            # 5. Run post-install hooks if any
            post_install = self.base_path / '.clawops' / 'post-install.sh'
            if post_install.exists():
                if verbose:
                    print(f"   🔧 Running post-install hooks...")
                try:
                    subprocess.run(['bash', str(post_install)], check=True)
                    if verbose:
                        print("   ✅ Post-install complete")
                except subprocess.CalledProcessError as e:
                    if verbose:
                        print(f"   ⚠️  Post-install warning: {e}")
            
            if verbose:
                print(f"\n✅ Update v{version} installed successfully!")
                if verify_result.get('manifest', {}).get('critical'):
                    print("   🚨 CRITICAL UPDATE APPLIED")
            
            result['success'] = True
            result['files_installed'] = files_installed
            
            return result
            
        except Exception as e:
            result['errors'].append(f"Installation failed: {str(e)}")
            return result
    
    def rollback(self, verbose: bool = True) -> dict:
        """
        Rollback to previous version.
        
        Restores files from rollback directory.
        """
        result = {
            'success': False,
            'version': None,
            'errors': []
        }
        
        if not self.registry.get('rollback_available'):
            result['errors'].append("No rollback point available")
            return result
        
        try:
            # Find latest rollback
            rollback_dirs = sorted(self.rollback_dir.glob('rollback-*'), reverse=True)
            
            if not rollback_dirs:
                result['errors'].append("Rollback directory not found")
                return result
            
            rollback_path = rollback_dirs[0]
            
            if verbose:
                print(f"\n↩️  Rolling back: {rollback_path.name}")
            
            # Restore files
            files_restored = 0
            
            for root, dirs, files in os.walk(rollback_path):
                for file in files:
                    src = Path(root) / file
                    rel = src.relative_to(rollback_path)
                    dst = self.base_path / rel
                    
                    if dst.exists():
                        # Backup current before restoring
                        backup_path = self.backup_dir / rel
                        backup_path.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(dst, backup_path)
                    
                    # Restore
                    shutil.copy2(src, dst)
                    files_restored += 1
            
            if verbose:
                print(f"   ✅ Restored {files_restored} files")
            
            # Update registry
            old_version = self.registry.get('current_version')
            self.registry['rollback_available'] = False
            self.registry['rollback_version'] = None
            self._save_registry()
            
            if verbose:
                print(f"\n↩️  Rolled back from v{old_version}")
                print(f"   Current state: Pre-update backup restored")
            
            result['success'] = True
            result['previous_version'] = old_version
            
            return result
            
        except Exception as e:
            result['errors'].append(f"Rollback failed: {str(e)}")
            return result
    
    def status(self, verbose: bool = True) -> dict:
        """Show current update status."""
        status = {
            'current_version': self.registry.get('current_version'),
            'rollback_available': self.registry.get('rollback_available', False),
            'rollback_version': self.registry.get('rollback_version'),
            'installed_updates': len(self.registry.get('installed_updates', []))
        }
        
        if verbose:
            print(f"\n{'='*50}")
            print(f"  UPDATE STATUS")
            print(f"{'='*50}")
            print(f"Current Version: {status['current_version'] or 'Unknown'}")
            print(f"Rollback Available: {'✅' if status['rollback_available'] else '❌'}")
            print(f"Total Installed: {status['installed_updates']}")
            print(f"{'='*50}\n")
        
        return status
    
    def list_available(self, verbose: bool = True) -> list:
        """List available update packages."""
        updates = []
        
        for item in self.updates_dir.glob('update-*'):
            if item.is_dir():
                manifest_path = item / 'manifest.yaml'
                if manifest_path.exists():
                    with open(manifest_path) as f:
                        manifest = yaml.safe_load(f)
                    updates.append({
                        'version': manifest.get('version'),
                        'description': manifest.get('description'),
                        'critical': manifest.get('critical'),
                        'path': str(item)
                    })
        
        if verbose:
            print(f"\n{'='*50}")
            print(f"  AVAILABLE UPDATES ({len(updates)})")
            print(f"{'='*50}")
            
            for update in sorted(updates, key=lambda x: x['version']):
                critical_icon = "🚨" if update.get('critical') else "📦"
                current = " (current)" if update['version'] == self.registry.get('current_version') else ""
                
                print(f"\n{critical_icon} v{update['version']}{current}")
                print(f"   {update.get('description', 'No description')}")
            
            print(f"\n{'='*50}\n")
        
        return updates
    
    def install_bundle(self, bundle_path: str, verbose: bool = True) -> dict:
        """
        Install from a tar.gz bundle.
        
        Extracts bundle to updates directory.
        """
        result = {
            'success': False,
            'updates_installed': [],
            'errors': []
        }
        
        try:
            if verbose:
                print(f"\n📦 Extracting bundle: {bundle_path}")
            
            with tarfile.open(bundle_path, 'r:gz') as tar:
                tar.extractall(path=self.updates_dir)
            
            if verbose:
                print("   ✅ Bundle extracted")
            
            # List installed updates
            updates = self.list_available(verbose=False)
            result['updates_installed'] = [u['version'] for u in updates]
            
            if verbose:
                print(f"\n✅ Bundle installed: {len(result['updates_installed'])} updates available")
            
            result['success'] = True
            return result
            
        except Exception as e:
            result['errors'].append(f"Bundle install failed: {str(e)}")
            return result


def main():
    parser = argparse.ArgumentParser(
        description='Offline Update Installer — For air-gapped ClawOps clients'
    )
    
    parser.add_argument(
        '--install',
        type=str,
        metavar='PACKAGE_PATH',
        help='Install an update package'
    )
    parser.add_argument(
        '--verify',
        type=str,
        metavar='PACKAGE_PATH',
        help='Verify a package without installing'
    )
    parser.add_argument(
        '--rollback',
        action='store_true',
        help='Rollback to previous version'
    )
    parser.add_argument(
        '--status',
        action='store_true',
        help='Show update status'
    )
    parser.add_argument(
        '--list',
        action='store_true',
        help='List available updates'
    )
    parser.add_argument(
        '--install-bundle',
        type=str,
        metavar='BUNDLE_PATH',
        help='Install from tar.gz bundle'
    )
    parser.add_argument(
        '--base-path',
        type=str,
        default='/root/.openclaw',
        help='Base path for ClawOps installation'
    )
    
    args = parser.parse_args()
    
    installer = UpdateInstaller(args.base_path)
    
    if args.install:
        result = installer.install(args.install)
        sys.exit(0 if result['success'] else 1)
    
    elif args.verify:
        result = installer.verify_package(args.verify)
        sys.exit(0 if result['valid'] else 1)
    
    elif args.rollback:
        result = installer.rollback()
        sys.exit(0 if result['success'] else 1)
    
    elif args.status:
        installer.status()
    
    elif args.list:
        installer.list_available()
    
    elif args.install_bundle:
        result = installer.install_bundle(args.install_bundle)
        sys.exit(0 if result['success'] else 1)
    
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
