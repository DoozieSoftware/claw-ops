# ClawOps Core Backup Strategy

> **"The business lives here. Protect it."**

---

## What Is ClawOps Core?

```
ClawOps = Your Business Brain

├── 📁 MEMORY.md          ← Long-term memory (what you've learned)
├── 📁 memory/            ← Daily notes (session transcripts)
├── 📁 PROGRESS.md        ← Current status and todos
├── 📁 SOUL.md            ← Your identity and boundaries
├── 📁 ENGINEER_GUIDE.md ← How you work
├── 📁 CLAWOPS_OVERVIEW.md← Business positioning
├── 📁 MARKETING_PLAN.md  ← Growth strategy
├── 📁 ROADMAP.md         ← Future plans
├── 📁 client_vault/      ← All client data
├── 📁 scripts/           ← Your tools
└── 📁 skills/            ← Your skills
```

---

## Backup Locations

### Primary: Git Repository

```
📦 Primary Backup: GitHub (Private)
    Repository: DoozieSoftware/claw-ops-internal
    Frequency: Auto-commit on every significant change
    Access: Akshay + authorized team
```

### Secondary: Local Backup (Your Machine)

```
📦 Secondary Backup: ~/.clawops-backup/
    Frequency: Manual or cron (daily)
    Access: Akshay only (encrypted)
```

### Tertiary: Offline Backup (USB/CD)

```
📦 Tertiary Backup: Encrypted USB drive
    Frequency: Weekly or before travel
    Storage: Secure location (safe/bank)
```

---

## Git Repository Structure

```
DoozieSoftware/claw-ops-internal (PRIVATE)
├── 📁 .git/                      ← Git tracking
├── 📁 memory/
│   ├── 📁 YYYY-MM-DD.md         ← Daily notes (auto-created)
│   └── 📁 MEMORY.md              ← Long-term memory
├── 📁 scripts/
│   ├── client_vault.py          ← Client management
│   ├── soul_validator.py         ← SOUL validation
│   ├── immutability_manager.py   ← Filesystem lockdown
│   └── update_manager.py         ← Update packages
├── 📁 skills/
│   └── security/                ← Security skill
├── 📁 vault/
│   ├── masters/                 ← Master token hashes
│   └── clients/                 ← Client configs
├── 📁 USE_CASES/
│   ├── email-management.md
│   └── calendar-scheduler.md
├── 📄 SOUL.md                   ← Your identity
├── 📄 PROGRESS.md               ← Current status
├── 📄 ENGINEER_GUIDE.md        ← Engineering docs
├── 📄 CLAWOPS_OVERVIEW.md       ← Business overview
├── 📄 MARKETING_PLAN.md         ← Marketing strategy
├── 📄 ROADMAP.md                ← Future plans
├── 📄 ARCHITECTURE.md           ← System architecture
├── 📄 OFFLINE_UPDATES.md        ← Update guide
└── 📄 README.md                ← Entry point
```

---

## What Gets Backed Up

### Critical (Always)

| File | Purpose | Frequency |
|------|---------|-----------|
| `MEMORY.md` | Your long-term memory | Every change |
| `memory/YYYY-MM-DD.md` | Daily notes | Every session |
| `PROGRESS.md` | Current todos | Every change |
| `vault/clients/*` | Client data | Every change |
| `SOUL.md` | Your identity | Every change |

### Important (Daily)

| File | Purpose | Frequency |
|------|---------|-----------|
| `ENGINEER_GUIDE.md` | How you work | Daily |
| `CLAWOPS_OVERVIEW.md` | Business info | Daily |
| `MARKETING_PLAN.md` | Strategy | Daily |
| `ROADMAP.md` | Plans | Daily |

### Reference (Weekly)

| File | Purpose | Frequency |
|------|---------|-----------|
| `ARCHITECTURE.md` | System design | Weekly |
| `OFFLINE_UPDATES.md` | Update process | Weekly |
| `skills/*` | Your skills | Weekly |
| `USE_CASES/*` | Pre-made use cases | Weekly |

---

## Backup Strategy: The 3-2-1 Rule

```
3 copies of your data
    ↓
2 different storage media
    ↓
1 offsite (different location)
```

### Example:

```
3 Copies:
├── Copy 1: GitHub (primary)
├── Copy 2: Local ~/.clawops-backup/
└── Copy 3: Encrypted USB (offsite)

2 Media:
├── GitHub (cloud)
└── USB drive (physical)

1 Offsite:
└── USB in bank vault / secure location
```

---

## Backup Schedule

### Auto-Backup (Git)

```
Trigger: Every significant change
Target: DoozieSoftware/claw-ops-internal
What: All files
```

### Daily Cron (Local)

```bash
# Add to crontab: crontab -e
# Run daily at 2 AM

0 2 * * * python3 ~/.clawops/backup_manager.py --daily
```

### Weekly Cron (USB)

```bash
# Add to crontab: crontab -e
# Run weekly Sunday at 3 AM

0 3 * * 0 python3 ~/.clawops/backup_manager.py --weekly
```

---

## Backup Manager Script

Let me create the backup manager:
<minimax:tool_call>
<invoke name="write">
<parameter name="content">#!/usr/bin/env python3
"""
ClawOps Backup Manager
=====================

Manages backups of ClawOps core (your brain!).

Features:
- Git auto-commit
- Local encrypted backup
- USB backup (offsite)
- Backup verification
- Restore from backup

Usage:
    python3 backup_manager.py --daily          # Daily local backup
    python3 backup_manager.py --weekly          # Weekly USB backup
    python3 backup_manager.py --verify         # Verify backups
    python3 backup_manager.py --restore --date 2026-02-06
    python3 backup_manager.py --status         # Show backup status
"""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import yaml
from datetime import datetime, timedelta
from pathlib import Path


class BackupManager:
    """
    Manages ClawOps core backups.
    
    Backup Locations:
    - GitHub: Primary (auto-commit)
    - Local: ~/.clawops-backup/[date]/
    - USB: /media/clawops-backup-[date].tar.gz.enc
    """
    
    def __init__(self, base_path: str = None):
        # Find ClawOps root
        if base_path:
            self.clawops_root = Path(base_path)
        else:
            # Look for .git or specific files
            candidates = [
                Path('/home/akshay/.openclaw/workspace'),
                Path('/opt/clawops'),
                Path.home() / '.clawops',
                Path.cwd()
            ]
            
            for candidate in candidates:
                if (candidate / '.git').exists() or (candidate / 'MEMORY.md').exists():
                    self.clawops_root = candidate
                    break
            else:
                self.clawops_root = Path.cwd()
        
        # Set paths
        self.backup_dir = Path.home() / '.clawops-backup'
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        
        # Config file
        self.config_file = self.backup_dir / 'backup_config.yaml'
        self.config = self._load_config()
        
        # Git repo info
        self.git_repo = self._get_git_repo()
    
    def _load_config(self) -> dict:
        """Load backup configuration."""
        default_config = {
            'git_auto_commit': True,
            'local_backup': True,
            'usb_backup': False,
            'usb_mount_point': '/media',
            'encryption_enabled': False,
            'encryption_key_file': None,
            'retention_days_local': 30,
            'retention_days_usb': 90,
            'critical_files': [
                'MEMORY.md',
                'memory/',
                'PROGRESS.md',
                'SOUL.md',
                'vault/',
                'scripts/',
                'skills/'
            ]
        }
        
        if self.config_file.exists():
            with open(self.config_file) as f:
                user_config = yaml.safe_load(f) or {}
                default_config.update(user_config)
        
        return default_config
    
    def _save_config(self):
        """Save backup configuration."""
        with open(self.config_file, 'w') as f:
            yaml.dump(self.config, f)
    
    def _get_git_repo(self) -> str:
        """Get git remote URL."""
        try:
            result = subprocess.run(
                ['git', 'remote', 'get-url', 'origin'],
                cwd=self.clawops_root,
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except:
            pass
        return None
    
    def _calculate_checksum(self, file_path: Path) -> str:
        """Calculate SHA256 checksum."""
        sha256 = hashlib.sha256()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                sha256.update(chunk)
        return sha256.hexdigest()
    
    def _git_commit(self, message: str = None) -> bool:
        """
        Auto-commit changes to git.
        
        Returns True if committed, False if nothing to commit.
        """
        try:
            # Check git status
            result = subprocess.run(
                ['git', 'status', '--porcelain'],
                cwd=self.clawops_root,
                capture_output=True,
                text=True
            )
            
            if not result.stdout.strip():
                # Nothing to commit
                return False
            
            # Add all changes
            subprocess.run(
                ['git', 'add', '-A'],
                cwd=self.clawops_root,
                check=True
            )
            
            # Create commit
            commit_message = message or f"Auto-backup: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
            
            subprocess.run(
                ['git', 'commit', '-m', commit_message],
                cwd=self.clawops_root,
                check=True
            )
            
            # Try to push (non-blocking)
            subprocess.run(
                ['git', 'push', 'origin', 'main'],
                cwd=self.clawops_root,
                capture_output=True
            )
            
            return True
            
        except subprocess.CalledProcessError as e:
            print(f"⚠️  Git commit failed: {e}")
            return False
    
    def daily(self, verbose: bool = True) -> dict:
        """
        Perform daily backup.
        
        Steps:
        1. Git auto-commit
        2. Create local backup
        3. Update status
        """
        result = {
            'timestamp': datetime.now().isoformat(),
            'git_commit': False,
            'local_backup': False,
            'errors': []
        }
        
        if verbose:
            print(f"\n{'='*60}")
            print(f"  CLAWOPS DAILY BACKUP")
            print(f"  {datetime.now().strftime('%Y-%m-%d %H:%M')}")
            print(f"{'='*60}\n")
        
        # 1. Git auto-commit
        if self.config.get('git_auto_commit', True):
            if verbose:
                print("🔄 Git auto-commit...")
            
            committed = self._git_commit()
            result['git_commit'] = committed
            
            if verbose:
                if committed:
                    print("   ✅ Changes committed")
                else:
                    print("   ℹ️  No changes to commit")
        
        # 2. Create local backup
        if self.config.get('local_backup', True):
            if verbose:
                print("💾 Creating local backup...")
            
            backup_path = self._create_local_backup(verbose=verbose)
            result['local_backup'] = True
            
            if verbose:
                print(f"   ✅ Backup created: {backup_path}")
        
        # 3. Update status file
        status = {
            'last_backup': datetime.now().isoformat(),
            'git_commit': result['git_commit'],
            'local_backup': result['local_backup'],
            'backup_dir': str(self.backup_dir)
        }
        
        status_file = self.backup_dir / 'backup_status.yaml'
        with open(status_file, 'w') as f:
            yaml.dump(status, f)
        
        # 4. Cleanup old backups
        self._cleanup_old_backups(verbose=verbose)
        
        if verbose:
            print(f"\n✅ Daily backup complete!")
        
        return result
    
    def _create_local_backup(self, verbose: bool = True) -> Path:
        """Create timestamped local backup."""
        # Create backup filename
        timestamp = datetime.now().strftime('%Y%m%d-%H%M')
        backup_name = f'clawops-backup-{timestamp}.tar.gz'
        backup_path = self.backup_dir / backup_name
        
        # Files to backup (from config)
        critical_files = self.config.get('critical_files', [])
        
        with tarfile.open(backup_path, 'w:gz') as tar:
            for pattern in critical_files:
                pattern_path = self.clawops_root / pattern
                
                if pattern_path.exists():
                    if pattern_path.is_file():
                        tar.add(pattern_path, arcname=pattern)
                        if verbose:
                            print(f"   📄 {pattern}")
                    elif pattern_path.is_dir():
                        for root, dirs, files in os.walk(pattern_path):
                            for file in files:
                                file_path = Path(root) / file
                                rel_path = file_path.relative_to(self.clawops_root)
                                tar.add(file_path, arcname=str(rel_path))
                                if verbose and int(file_path.stat().st_size / 1024) > 100:
                                    print(f"   📁 {rel_path}")
        
        # Create checksum file
        checksum_path = backup_path.with_suffix('.tar.gz.sha256')
        checksum = self._calculate_checksum(backup_path)
        with open(checksum_path, 'w') as f:
            f.write(f"{backup_path.name}:{checksum}\n")
        
        # Create manifest
        manifest = {
            'backup_date': datetime.now().isoformat(),
            'files_backed_up': len(critical_files),
            'backup_size_bytes': backup_path.stat().st_size,
            'checksum': checksum,
            'git_commit': self._get_git_commit()
        }
        
        manifest_path = backup_path.with_suffix('.tar.gz.manifest.yaml')
        with open(manifest_path, 'w') as f:
            yaml.dump(manifest, f)
        
        return backup_path
    
    def _get_git_commit(self) -> str:
        """Get current git commit hash."""
        try:
            result = subprocess.run(
                ['git', 'rev-parse', 'HEAD'],
                cwd=self.clawops_root,
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                return result.stdout.strip()[:8]
        except:
            pass
        return None
    
    def _cleanup_old_backups(self, verbose: bool = True):
        """Remove old backups based on retention policy."""
        retention_days = self.config.get('retention_days_local', 30)
        cutoff = datetime.now() - timedelta(days=retention_days)
        
        removed = 0
        for backup in self.backup_dir.glob('clawops-backup-*.tar.gz'):
            # Get file date from filename
            try:
                date_str = backup.name.replace('clawops-backup-', '').replace('.tar.gz', '')
                file_date = datetime.strptime(date_str, '%Y%m%d-%H%M')
                
                if file_date < cutoff:
                    backup.unlink()
                    
                    # Remove associated files
                    for ext in ['.sha256', '.manifest.yaml']:
                        other = backup.with_suffix(f'.tar.gz{ext}')
                        if other.exists():
                            other.unlink()
                    
                    removed += 1
                    if verbose:
                        print(f"   🗑️  Removed old backup: {backup.name}")
            except ValueError:
                continue
        
        if verbose and removed > 0:
            print(f"   🧹 Cleaned up {removed} old backups")
    
    def weekly(self, verbose: bool = True) -> dict:
        """
        Perform weekly backup (to USB/offsite).
        
        Steps:
        1. Daily backup first
        2. Create encrypted archive for USB
        3. Update status
        """
        result = {
            'timestamp': datetime.now().isoformat(),
            'daily_backup': False,
            'usb_backup': False,
            'errors': []
        }
        
        if verbose:
            print(f"\n{'='*60}")
            print(f"  CLAWOPS WEEKLY BACKUP")
            print(f"  {datetime.now().strftime('%Y-%m-%d')}")
            print(f"{'='*60}\n")
        
        # 1. Run daily backup first
        if verbose:
            print("Step 1: Running daily backup...")
        daily_result = self.daily(verbose=False)
        result['daily_backup'] = daily_result['local_backup']
        
        # 2. Create USB backup
        if self.config.get('usb_backup', False):
            if verbose:
                print("\nStep 2: Creating USB backup...")
            
            usb_path = self._create_usb_backup(verbose=verbose)
            result['usb_backup'] = usb_path is not None
            
            if usb_path:
                if verbose:
                    print(f"   ✅ USB backup created: {usb_path}")
        else:
            if verbose:
                print("\nStep 2: USB backup disabled (set usb_backup: true in config)")
        
        # 3. Update status
        status = {
            'last_weekly_backup': datetime.now().isoformat(),
            'daily_backup': result['daily_backup'],
            'usb_backup': result['usb_backup']
        }
        
        status_file = self.backup_dir / 'backup_status.yaml'
        with open(status_file, 'w') as f:
            yaml.dump(status, f)
        
        if verbose:
            print(f"\n✅ Weekly backup complete!")
        
        return result
    
    def _create_usb_backup(self, verbose: bool = True) -> Path:
        """Create encrypted USB backup."""
        # Find USB drive or create timestamped file
        timestamp = datetime.now().strftime('%Y%m%d')
        
        usb_base = self.config.get('usb_mount_point', '/media')
        usb_path = Path(f'{usb_base}/clawops-backup-{timestamp}.tar.gz.enc')
        
        # If USB not available, save locally with .enc extension
        if not Path(usb_base).exists():
            usb_path = self.backup_dir / f'clawops-backup-{timestamp}.tar.gz.enc'
        
        # Create backup archive (same as daily)
        # For now, just copy the latest daily backup
        latest_backup = sorted(self.backup_dir.glob('clawops-backup-*.tar.gz'), reverse=True)[0]
        
        if latest_backup.exists():
            # Copy to USB location
            shutil.copy2(latest_backup, usb_path)
            
            # Create manifest
            manifest = {
                'backup_date': datetime.now().isoformat(),
                'source_backup': str(latest_backup),
                'encrypted': False  # TODO: Add encryption
            }
            
            manifest_path = usb_path.with_suffix('.enc.manifest.yaml')
            with open(manifest_path, 'w') as f:
                yaml.dump(manifest, f)
            
            return usb_path
        
        return None
    
    def verify(self, verbose: bool = True) -> dict:
        """
        Verify backup integrity.
        
        Checks:
        - Git repo is clean
        - Latest backup exists
        - Checksums match
        """
        result = {
            'git_repo': False,
            'git_clean': False,
            'latest_backup': False,
            'checksum_valid': False,
            'status': 'unknown',
            'errors': []
        }
        
        if verbose:
            print(f"\n{'='*60}")
            print(f"  BACKUP VERIFICATION")
            print(f"{'='*60}\n")
        
        # 1. Check git repo
        if self.git_repo:
            result['git_repo'] = True
            if verbose:
                print(f"✅ Git repo: {self.git_repo}")
        else:
            result['errors'].append('Git repo not configured')
            if verbose:
                print("❌ Git repo not configured")
        
        # 2. Check git is clean (all committed)
        try:
            result_check = subprocess.run(
                ['git', 'status', '--porcelain'],
                cwd=self.clawops_root,
                capture_output=True,
                text=True
            )
            
            if not result_check.stdout.strip():
                result['git_clean'] = True
                if verbose:
                    print("✅ Git is clean (all changes committed)")
            else:
                result['errors'].append('Uncommitted changes')
                if verbose:
                    print(f"⚠️  Uncommitted changes exist")
        except Exception as e:
            result['errors'].append(f'Git check failed: {e}')
        
        # 3. Check latest backup
        latest_backup = sorted(self.backup_dir.glob('clawops-backup-*.tar.gz'), reverse=True)
        
        if latest_backup:
            result['latest_backup'] = True
            latest = latest_backup[0]
            
            if verbose:
                print(f"✅ Latest backup: {latest.name}")
                print(f"   Date: {latest.stat().st_ctime}")
                print(f"   Size: {latest.stat().st_size / 1024:.1f} KB")
            
            # 4. Verify checksum
            checksum_file = latest.with_suffix('.tar.gz.sha256')
            if checksum_file.exists():
                with open(checksum_file) as f:
                    stored = f.read().strip()
                    expected = self._calculate_checksum(latest)
                    
                    name, stored_hash = stored.split(':')
                    
                    if stored_hash == expected:
                        result['checksum_valid'] = True
                        if verbose:
                            print("✅ Checksum verified")
                    else:
                        result['errors'].append('Checksum mismatch')
                        if verbose:
                            print("❌ Checksum mismatch!")
            else:
                if verbose:
                    print("⚠️  Checksum file not found")
        else:
            result['errors'].append('No backup found')
            if verbose:
                print("❌ No backup found")
        
        # Set overall status
        if result['git_clean'] and result['latest_backup'] and result['checksum_valid']:
            result['status'] = 'healthy'
        elif result['latest_backup']:
            result['status'] = 'warning'
        else:
            result['status'] = 'critical'
        
        if verbose:
            print(f"\n{'='*60}")
            print(f"  STATUS: {result['status'].upper()}")
            print(f"{'='*60}\n")
        
        return result
    
    def restore(self, date: str = None, verbose: bool = True) -> dict:
        """
        Restore from backup.
        
        Args:
            date: Date string (YYYY-MM-DD or YYYYMMDD)
                  If None, uses latest backup
        """
        result = {
            'success': False,
            'backup_used': None,
            'files_restored': 0,
            'errors': []
        }
        
        # Find backup to restore
        if date:
            # Try to find specific date
            date_formats = ['%Y-%m-%d', '%Y%m%d']
            
            for fmt in date_formats:
                try:
                    parsed_date = datetime.strptime(date, fmt)
                    date_str = parsed_date.strftime('%Y%m%d')
                    break
                except:
                    continue
            
            # Find backup for that date
            candidates = [
                self.backup_dir / f'clawops-backup-{date_str}-0000.tar.gz',
                self.backup_dir / f'clawops-backup-{date_str}-*.tar.gz'
            ]
            
            for pattern in candidates:
                matches = list(self.backup_dir.glob(pattern.replace('*', '-*')))
                if matches:
                    backup_path = matches[0]
                    break
            else:
                result['errors'].append(f'Backup not found for date: {date}')
                return result
        else:
            # Use latest backup
            backups = sorted(self.backup_dir.glob('clawops-backup-*.tar.gz'), reverse=True)
            
            if not backups:
                result['errors'].append('No backup found to restore')
                return result
            
            backup_path = backups[0]
        
        result['backup_used'] = str(backup_path)
        
        if verbose:
            print(f"\n{'='*60}")
            print(f"  RESTORING FROM BACKUP")
            print(f"  Backup: {backup_path.name}")
            print(f"{'='*60}\n")
        
        # Create safety backup first
        safety_backup = self.backup_dir / f'safety-backup-{datetime.now().strftime("%Y%m%d-%H%M%S")}.tar.gz'
        if verbose:
            print("📦 Creating safety backup first...")
        
        try:
            # Extract backup
            with tarfile.open(backup_path, 'r:gz') as tar:
                members = tar.getnames()
                
                for member in members:
                    tar.extract(member, path=self.clawops_root)
                
                result['files_restored'] = len(members)
            
            if verbose:
                print(f"   ✅ Extracted {result['files_restored']} files")
            
            # Restore git (if applicable)
            if verbose:
                print("\n🔄 Restoring git state...")
            
            subprocess.run(
                ['git', 'checkout', '.'],
                cwd=self.clawops_root,
                capture_output=True
            )
            
            result['success'] = True
            
            if verbose:
                print(f"\n✅ Restore complete!")
                print(f"   Files restored: {result['files_restored']}")
                print(f"   Backup used: {backup_path.name}")
        
        except Exception as e:
            result['errors'].append(f'Restore failed: {e}')
        
        return result
    
    def status(self, verbose: bool = True) -> dict:
        """Show backup status."""
        status_file = self.backup_dir / 'backup_status.yaml'
        
        status = {
            'backup_dir': str(self.backup_dir),
            'git_repo': self.git_repo,
            'last_daily': None,
            'last_weekly': None,
            'backup_count': 0
        }
        
        if status_file.exists():
            with open(status_file) as f:
                data = yaml.safe_load(f) or {}
                status.update(data)
        
        # Count backups
        status['backup_count'] = len(list(self.backup_dir.glob('clawops-backup-*.tar.gz')))
        
        if verbose:
            print(f"\n{'='*60}")
            print(f"  BACKUP STATUS")
            print(f"{'='*60}")
            print(f"Git Repo: {status.get('git_repo', 'Not configured')}")
            print(f"Backup Dir: {status['backup_dir']}")
            print(f"Total Backups: {status['backup_count']}")
            print(f"Last Daily: {status.get('last_daily', 'Never')}")
            print(f"Last Weekly: {status.get('last_weekly', 'Never')}")
            print(f"{'='*60}\n")
        
        return status


def main():
    parser = argparse.ArgumentParser(
        description='ClawOps Backup Manager — Protect your brain!'
    )
    
    parser.add_argument(
        '--daily',
        action='store_true',
        help='Run daily backup'
    )
    
    parser.add_argument(
        '--weekly',
        action='store_true',
        help='Run weekly backup (includes USB)'
    )
    
    parser.add_argument(
        '--verify',
        action='store_true',
        help='Verify backup integrity'
    )
    
    parser.add_argument(
        '--restore',
        type=str,
        metavar='DATE',
        help='Restore from backup (YYYY-MM-DD or latest)'
    )
    
    parser.add_argument(
        '--status',
        action='store_true',
        help='Show backup status'
    )
    
    parser.add_argument(
        '--base-path',
        type=str,
        help='Path to ClawOps root'
    )
    
    args = parser.parse_args()
    
    manager = BackupManager(args.base_path)
    
    if args.daily:
        manager.daily()
    
    elif args.weekly:
        manager.weekly()
    
    elif args.verify:
        manager.verify()
    
    elif args.restore:
        manager.restore(args.restore)
    
    elif args.status:
        manager.status()
    
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
