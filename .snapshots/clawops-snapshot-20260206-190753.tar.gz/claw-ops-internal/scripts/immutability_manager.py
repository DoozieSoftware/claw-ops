#!/usr/bin/env python3
"""
Immutability Manager — Filesystem Lockdown System
=================================================

Makes the OpenClaw deployment immutable with controlled edit windows.

Philosophy:
- Layer 1: CORE (skills, node_modules) → IMMUTABLE (Master Token only)
- Layer 2: CONFIGS (SOUL.md, USE_CASES) → LOCKED (Client Token or Master Token)
- Layer 3: MEMORY/BRAIN → ALWAYS MUTABLE (Agent needs this!)
- Layer 4: LOGS → Append-only

Usage:
    python3 immutability_manager.py --lock
    python3 immutability_manager.py --unlock --token [TOKEN]
    python3 immutability_manager.py --relock
    python3 immutability_manager.py --status
    python3 immutability_manager.py --verify
"""

import argparse
import hashlib
import json
import os
import secrets
import stat
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path


class ImmutabilityManager:
    """
    Manages filesystem immutability for ClawOps deployments.
    
    Philosophy:
    - Core files: IMMUTABLE (no changes after deployment)
    - Config files: LOCKED by default, requires TOKEN to edit
    - Memory/Files: ALWAYS MUTABLE (this is the agent's BRAIN!)
    - Client Edit Tokens: Single-use, time-limited for controlled access
    
    Security Layers:
    ┌─────────────────────────────────────────────────────────────┐
    │  LAYER 1: Core OpenClaw (SKILLS, NODE_MODULES)            │
    │  Status: 🔒 IMMUTABLE (no changes after deployment)        │
    │  Access: Master Token only                                  │
    ├─────────────────────────────────────────────────────────────┤
    │  LAYER 2: Configs (SOUL.md, USE_CASES, configs)           │
    │  Status: 🔐 LOCKED (controlled via tokens)                │
    │  Access: Client Token OR Master Token                      │
    ├─────────────────────────────────────────────────────────────┤
    │  LAYER 3: Memory & Context (memory/, data/, context/)     │
    │  Status: 🔓 ALWAYS MUTABLE (AGENT BRAIN - MUST be mutable) │
    │  Access: Always writable (this is the assistant!)          │
    ├─────────────────────────────────────────────────────────────┤
    │  LAYER 4: Logs (logs/)                                     │
    │  Status: 🔓 Append-only (audit trail)                      │
    │  Access: Always writable                                   │
    └─────────────────────────────────────────────────────────────┘
    """
    
    # Paths that are ALWAYS immutable (Core System)
    # ONLY Master Token can modify these
    IMMUTABLE_CORE = [
        '/root/.openclaw/core',
        '/root/.openclaw/skills',
        '/root/.openclaw/node_modules',
        '/root/.openclaw/package.json',
        '/root/.openclaw/package-lock.json',
        '/opt/clawops/scripts',  # Validator scripts
        '/opt/clawops/templates',
        '/opt/clawops/USE_CASES',
    ]
    
    # Paths that are LOCKED by default but unlockable via token
    # Can be modified with Client Token or Master Token
    LOCKED_PATHS = [
        '/root/.openclaw/config',
        '/root/.openclaw/clients',
    ]
    
    # Paths that are ALWAYS mutable (AGENT BRAIN!)
    # These MUST be writable - they're the agent's memory
    ALWAYS_MUTABLE = [
        '/root/.openclaw/memory',      # Long-term memory (critical!)
        '/root/.openclaw/data',         # User data, learned patterns
        '/root/.openclaw/context',      # Conversation context
        '/root/.openclaw/.claude',      # Claude memory (if exists)
        '/root/.openclaw/gpts',         # GPT configurations
    ]
    
    # Paths that are append-only (audit logs)
    APPEND_ONLY = [
        '/root/.openclaw/logs',
    ]
    
    # Token validity duration (in seconds)
    TOKEN_VALIDITY_SECONDS = 3600  # 1 hour
    
    def __init__(self, base_path: str = '/root/.openclaw'):
        self.base_path = Path(base_path)
        self.token_file = Path('/opt/clawops/.edit_tokens.json')
        self.lock_file = Path('/opt/clawops/.immutability_status.json')
        self.master_vault = Path('/opt/clawops/vault/masters')
        
        # Ensure token file exists
        if not self.token_file.exists():
            self.token_file.write_text('{}')
        
        # Ensure master vault exists
        self.master_vault.mkdir(parents=True, exist_ok=True)
        os.chmod(self.master_vault, stat.S_IRWXU)  # 700
    
    def _calculate_checksum(self, file_path: Path) -> str:
        """Calculate SHA256 checksum of a file."""
        if not file_path.exists() or not file_path.is_file():
            return ''
        sha256 = hashlib.sha256()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                sha256.update(chunk)
        return sha256.hexdigest()
    
    def _get_all_files(self, path: Path) -> list:
        """Get all files in a directory recursively."""
        files = []
        if path.exists() and path.is_dir():
            for item in path.rglob('*'):
                if item.is_file():
                    files.append(item)
        return files
    
    def _validate_master_token(self, token: str) -> bool:
        """Validate a master token against stored hash."""
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        
        # Check against all master token files
        for master_file in self.master_vault.glob('*.hash'):
            with open(master_file) as f:
                stored_hash = f.read().strip()
            if stored_hash == token_hash:
                return True
        return False
    
    def _is_master_token(self, token: str) -> bool:
        """Check if token is a master token (format: ...master....)"""
        return '.master.' in token
    
    def lock(self, verbose: bool = True) -> dict:
        """
        Lock the filesystem (make immutable).
        
        Returns status report with:
        - Files locked
        - Checksums recorded
        - Writable paths
        """
        status = {
            'timestamp': datetime.utcnow().isoformat(),
            'action': 'lock',
            'files_locked': 0,
            'checksums_recorded': 0,
            'mutable_paths': [],
            'locked_paths': [],
            'immutable_paths': [],
            'errors': []
        }
        
        if verbose:
            print("🔒 Locking filesystem...")
            print("")
        
        # 1. Lock IMMUTABLE_CORE paths (truly immutable)
        for path_str in self.IMMUTABLE_CORE:
            path = Path(path_str)
            if path.exists():
                try:
                    for item in path.rglob('*'):
                        if item.is_file():
                            os.chmod(item, stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH)  # 444
                            status['files_locked'] += 1
                    status['immutable_paths'].append(str(path))
                    if verbose:
                        print(f"  🔒 Immutable (Master Token only): {path}")
                except Exception as e:
                    status['errors'].append(f"Error locking {path}: {e}")
        
        # 2. Lock LOCKED_PATHS (token-protected)
        for path_str in self.LOCKED_PATHS:
            path = Path(path_str)
            # Create if not exists
            path.mkdir(parents=True, exist_ok=True)
            try:
                for item in path.rglob('*'):
                    if item.is_file():
                        os.chmod(item, stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH)  # 444
                        status['files_locked'] += 1
                status['locked_paths'].append(str(path))
                if verbose:
                    print(f"  🔐 Locked (Token required): {path}")
            except Exception as e:
                status['errors'].append(f"Error locking {path}: {e}")
        
        # 3. Ensure ALWAYS_MUTABLE paths are writable (AGENT BRAIN!)
        for path_str in self.ALWAYS_MUTABLE + self.APPEND_ONLY:
            path = Path(path_str)
            path.mkdir(parents=True, exist_ok=True)
            try:
                os.chmod(path, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)  # 777
                status['mutable_paths'].append(str(path))
                if verbose:
                    print(f"  🔓 Mutable (Agent Brain): {path}")
            except Exception as e:
                status['errors'].append(f"Error setting mutable {path}: {e}")
        
        # 4. Record checksums for integrity verification (only immutable + locked)
        checksums = {}
        for path_str in self.IMMUTABLE_CORE + self.LOCKED_PATHS:
            path = Path(path_str)
            if path.exists():
                for item in path.rglob('*'):
                    if item.is_file():
                        checksums[str(item)] = self._calculate_checksum(item)
        
        status['checksums_recorded'] = len(checksums)
        
        # Save lock status with checksums
        lock_data = {
            'status': 'LOCKED',
            'locked_at': status['timestamp'],
            'checksums': checksums,
            'immutable_paths': status['immutable_paths'],
            'locked_paths': status['locked_paths'],
            'mutable_paths': status['mutable_paths']
        }
        
        with open(self.lock_file, 'w') as f:
            json.dump(lock_data, f, indent=2)
        
        if verbose:
            print("")
            print(f"✅ Filesystem locked")
            print(f"   Immutable (Master only): {len(status['immutable_paths'])} paths")
            print(f"   Locked (Token required): {len(status['locked_paths'])} paths")
            print(f"   Mutable (Agent Brain): {len(status['mutable_paths'])} paths")
            print(f"   Checksums recorded: {status['checksums_recorded']}")
        
        if status['errors']:
            print(f"\n⚠️  Errors encountered:")
            for err in status['errors']:
                print(f"   - {err}")
        
        return status
    
    def generate_client_token(self, client_name: str, verbose: bool = True) -> str:
        """
        Generate a single-use edit token for a client.
        """
        # Load existing tokens
        with open(self.token_file) as f:
            tokens = json.load(f)
        
        # Generate new token
        token = secrets.token_urlsafe(32)
        token_hash = hashlib.sha256(token.encode()).hexdigest()[:16]
        
        token_id = f"{client_name}-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        
        tokens[token_id] = {
            'token_hash': hashlib.sha256(token.encode()).hexdigest(),
            'client': client_name,
            'created_at': datetime.utcnow().isoformat(),
            'expires_at': (datetime.utcnow() + timedelta(seconds=self.TOKEN_VALIDITY_SECONDS)).isoformat(),
            'used': False,
            'type': 'client_edit'
        }
        
        with open(self.token_file, 'w') as f:
            json.dump(tokens, f, indent=2)
        
        if verbose:
            print(f"🎫 Client edit token generated for: {client_name}")
            print(f"   Token ID: {token_id}")
            print(f"   Valid for: {self.TOKEN_VALIDITY_SECONDS // 60} minutes")
            print(f"   Token: {token}")
            print(f"\n⚠️  SAVE THIS TOKEN — It won't be shown again!")
        
        return token
    
    def unlock(self, token: str, verbose: bool = True) -> bool:
        """
        Unlock filesystem for editing using a valid token.
        
        Returns True if unlocked successfully.
        """
        # Check if master token
        is_master = self._is_master_token(token)
        
        if is_master:
            if not self._validate_master_token(token):
                if verbose:
                    print("❌ Invalid master token")
                return False
            unlock_type = "MASTER TOKEN"
        else:
            # Validate client token
            with open(self.token_file) as f:
                tokens = json.load(f)
            
            token_hash = hashlib.sha256(token.encode()).hexdigest()
            valid_token_id = None
            
            for token_id, token_data in tokens.items():
                if token_data['token_hash'] == token_hash:
                    if token_data['used']:
                        if verbose:
                            print("❌ Token already used")
                        return False
                    
                    expiry = datetime.fromisoformat(token_data['expires_at'])
                    if datetime.utcnow() > expiry:
                        if verbose:
                            print("❌ Token expired")
                        return False
                    
                    valid_token_id = token_id
                    break
            
            if not valid_token_id:
                if verbose:
                    print("❌ Invalid token")
                return False
            
            # Mark as used
            tokens[valid_token_id]['used'] = True
            with open(self.token_file, 'w') as f:
                json.dump(tokens, f, indent=2)
            
            unlock_type = f"CLIENT TOKEN ({tokens[valid_token_id]['client']})"
        
        # Unlock LOCKED_PATHS (IMMUTABLE_CORE stays locked for client tokens)
        if is_master:
            # Master token can unlock everything
            paths_to_unlock = self.IMMUTABLE_CORE + self.LOCKED_PATHS
            unlock_msg = "MASTER TOKEN - Full access"
        else:
            # Client token can only unlock LOCKED_PATHS
            paths_to_unlock = self.LOCKED_PATHS
            unlock_msg = "CLIENT TOKEN - Configs only"
        
        for path_str in paths_to_unlock:
            path = Path(path_str)
            if path.exists():
                try:
                    for item in path.rglob('*'):
                        if item.is_file():
                            os.chmod(item, stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IWGRP | stat.S_IROTH)
                    if verbose:
                        print(f"  🔓 Unlocked: {path}")
                except Exception as e:
                    if verbose:
                        print(f"⚠️  Error unlocking {path}: {e}")
        
        # Update lock status
        with open(self.lock_file, 'r') as f:
            lock_data = json.load(f)
        
        lock_data['status'] = 'UNLOCKED'
        lock_data['unlocked_at'] = datetime.utcnow().isoformat()
        lock_data['unlock_type'] = unlock_type
        lock_data['is_master'] = is_master
        
        with open(self.lock_file, 'w') as f:
            json.dump(lock_data, f, indent=2)
        
        if verbose:
            print(f"\n✅ Filesystem UNLOCKED ({unlock_type})")
            print(f"")
            print(f"⚠️  EDITS COMPLETE? Run --relock when done!")
        
        return True
    
    def relock(self, verbose: bool = True) -> dict:
        """Relock the filesystem after edits."""
        with open(self.lock_file) as f:
            lock_data = json.load(f)
        
        if lock_data.get('status') != 'UNLOCKED':
            if verbose:
                print("⚠️  Filesystem is not unlocked. Nothing to relock.")
            return {'action': 'none', 'status': lock_data.get('status')}
        
        is_master = lock_data.get('is_master', False)
        
        # Record new checksums after edits (only for what was locked)
        if is_master:
            paths_to_relock = self.IMMUTABLE_CORE + self.LOCKED_PATHS
        else:
            paths_to_relock = self.LOCKED_PATHS
        
        checksums = {}
        for path_str in paths_to_relock:
            path = Path(path_str)
            if path.exists():
                for item in path.rglob('*'):
                    if item.is_file():
                        checksums[str(item)] = self._calculate_checksum(item)
        
        # Relock paths
        for path_str in paths_to_relock:
            path = Path(path_str)
            if path.exists():
                try:
                    for item in path.rglob('*'):
                        if item.is_file():
                            os.chmod(item, stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH)
                    if verbose:
                        print(f"  🔒 Relocked: {path}")
                except Exception as e:
                    if verbose:
                        print(f"⚠️  Error relocking {path}: {e}")
        
        # Update lock status
        lock_data['status'] = 'LOCKED'
        lock_data['relocked_at'] = datetime.utcnow().isoformat()
        lock_data['checksums'] = checksums
        lock_data['checksums_recorded'] = len(checksums)
        lock_data.pop('unlock_type', None)
        lock_data.pop('is_master', None)
        
        with open(self.lock_file, 'w') as f:
            json.dump(lock_data, f, indent=2)
        
        if verbose:
            print(f"\n✅ Filesystem RELOCKED")
            print(f"   Checksums updated: {len(checksums)}")
        
        return {'action': 'relock', 'status': 'LOCKED'}
    
    def verify_integrity(self, verbose: bool = True) -> dict:
        """Verify that immutable files haven't been modified."""
        with open(self.lock_file) as f:
            lock_data = json.load(f)
        
        recorded_checksums = lock_data.get('checksums', {})
        
        violations = []
        for file_path, expected_hash in recorded_checksums.items():
            current_hash = self._calculate_checksum(Path(file_path))
            
            if current_hash != expected_hash:
                violations.append({
                    'file': file_path,
                    'status': 'MODIFIED'
                })
        
        result = {
            'status': 'LOCKED',
            'verified_at': datetime.utcnow().isoformat(),
            'files_verified': len(recorded_checksums),
            'violations': violations,
            'integrity': 'VALID' if not violations else 'VIOLATED'
        }
        
        if verbose:
            if not violations:
                print("✅ INTEGRITY CHECK PASSED")
                print(f"   Files verified: {len(recorded_checksums)}")
            else:
                print("⚠️  INTEGRITY VIOLATIONS DETECTED!")
                print(f"   Files verified: {len(recorded_checksums)}")
                print(f"   Violations: {len(violations)}")
                for v in violations:
                    print(f"   - {v['file']}: {v['status']}")
        
        return result
    
    def status(self, verbose: bool = True) -> dict:
        """Show current immutability status."""
        if not self.lock_file.exists():
            status = {'status': 'NEVER_LOCKED'}
        else:
            with open(self.lock_file) as f:
                status = json.load(f)
        
        if verbose:
            print(f"\n{'='*55}")
            print(f"  IMMUTABILITY STATUS")
            print(f"{'='*55}")
            print(f"Status: {status.get('status', 'UNKNOWN')}")
            
            if 'locked_at' in status:
                print(f"Locked at: {status['locked_at'][:19]}")
            if 'unlocked_at' in status:
                print(f"Unlocked at: {status['unlocked_at'][:19]}")
                print(f"Unlock type: {status.get('unlock_type', 'Unknown')}")
            if 'relocked_at' in status:
                print(f"Relocked at: {status['relocked_at'][:19]}")
            
            print(f"")
            print(f"🔒 Immutable (Master only): {len(status.get('immutable_paths', []))} paths")
            print(f"🔐 Locked (Token required): {len(status.get('locked_paths', []))} paths")
            print(f"🔓 Mutable (Agent Brain): {len(status.get('mutable_paths', []))} paths")
            print(f"")
            print(f"Files protected: {len(status.get('checksums', {}))}")
            print(f"{'='*55}\n")
        
        return status


def main():
    parser = argparse.ArgumentParser(
        description='Immutability Manager — Filesystem Lockdown System'
    )
    parser.add_argument('--lock', action='store_true', help='Lock the filesystem')
    parser.add_argument('--unlock', action='store_true', help='Unlock for editing')
    parser.add_argument('--token', type=str, help='Token for --unlock')
    parser.add_argument('--relock', action='store_true', help='Relock after editing')
    parser.add_argument('--status', action='store_true', help='Show current status')
    parser.add_argument('--verify', action='store_true', help='Verify integrity')
    parser.add_argument('--generate-token', type=str, help='Generate client edit token')
    parser.add_argument('--base-path', type=str, default='/root/.openclaw', help='Base path')
    
    args = parser.parse_args()
    
    manager = ImmutabilityManager(args.base_path)
    
    if args.status:
        manager.status()
    elif args.lock:
        manager.lock()
    elif args.unlock:
        if not args.token:
            print("❌ --token required for --unlock")
            sys.exit(1)
        success = manager.unlock(args.token)
        sys.exit(0 if success else 1)
    elif args.relock:
        manager.relock()
    elif args.verify:
        manager.verify_integrity()
    elif args.generate_token:
        manager.generate_client_token(args.generate_token)
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
