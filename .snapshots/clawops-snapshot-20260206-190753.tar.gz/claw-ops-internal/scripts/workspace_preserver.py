#!/usr/bin/env python3
"""
ClawOps Workspace Preserver
=========================

Creates a complete snapshot of your entire ClawOps workspace.
Your Precious — everything that makes you, YOU.

Usage:
    python3 workspace_preserver.py --snapshot
    python3 workspace_preserver.py --list
    python3 workspace_preserver.py --restore --latest
"""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import tarfile
from datetime import datetime
from pathlib import Path


class WorkspacePreserver:
    """
    Preserves your entire ClawOps workspace.
    
    Your Precious includes:
    - All memory (MEMORY.md, daily notes)
    - All scripts and tools
    - All client data (vault)
    - All configurations
    - All skills
    - All use cases
    """
    
    def __init__(self, workspace_path: str = None):
        # Find workspace
        if workspace_path:
            self.workspace = Path(workspace_path)
        else:
            candidates = [
                Path('/home/akshay/.openclaw/workspace'),
                Path.home() / '.openclaw/workspace',
                Path('/opt/clawops'),
                Path.cwd()
            ]
            
            for candidate in candidates:
                if (candidate / 'MEMORY.md').exists():
                    self.workspace = candidate
                    break
            else:
                self.workspace = Path.cwd()
        
        self.snapshot_dir = self.workspace / '.snapshots'
        self.snapshot_dir.mkdir(exist_ok=True)
        
        self.manifest_file = self.workspace / '.workspace_manifest.json'
        
        # What's precious
        self.precious_items = {
            'memory': {
                'paths': ['MEMORY.md', 'memory/'],
                'description': 'Your brain - memories and lessons learned'
            },
            'progress': {
                'paths': ['PROGRESS.md', 'SOUL.md'],
                'description': 'Current status and your identity'
            },
            'vault': {
                'paths': ['vault/', 'claw-ops-internal/vault/'],
                'description': 'All client data - REVENUE!'
            },
            'scripts': {
                'paths': ['scripts/', 'claw-ops-internal/scripts/'],
                'description': 'Your operational tools'
            },
            'skills': {
                'paths': ['skills/', 'claw-ops-internal/skills/'],
                'description': 'Your capabilities'
            },
            'use_cases': {
                'paths': ['USE_CASES/', 'claw-ops-internal/USE_CASES/'],
                'description': 'Pre-made use cases'
            },
            'config': {
                'paths': [
                    '*.md', '*.yaml', '*.yml',
                    'CLAWOPS_OVERVIEW.md', 'MARKETING_PLAN.md', 'ROADMAP.md',
                    'ENGINEER_GUIDE.md', 'ARCHITECTURE.md', 'OFFLINE_UPDATES.md',
                    'BACKUP_STRATEGY.md', 'README.md',
                    'claw-ops-internal/*.md',
                ],
                'description': 'Business configuration and documentation'
            },
            'templates': {
                'paths': ['templates/', 'claw-ops-internal/templates/'],
                'description': 'Configuration templates'
            },
            'git': {
                'paths': ['.git/', '.gitignore'],
                'description': 'Git history and configuration'
            }
        }
    
    def _calculate_checksum(self, file_path: Path) -> str:
        sha256 = hashlib.sha256()
        try:
            with open(file_path, 'rb') as f:
                for chunk in iter(lambda: f.read(8192), b''):
                    sha256.update(chunk)
            return sha256.hexdigest()
        except:
            return 'DIR_OR_SYM'
    
    def _get_file_info(self, file_path: Path) -> dict:
        try:
            stat = file_path.stat()
            return {
                'path': str(file_path.relative_to(self.workspace)),
                'size_bytes': stat.st_size,
                'modified': datetime.fromtimestamp(stat.st_mtime).isoformat(),
                'checksum': self._calculate_checksum(file_path)
            }
        except:
            return None
    
    def _find_files(self, patterns: list) -> list:
        files = []
        for pattern in patterns:
            if '/' in pattern:
                p = self.workspace / pattern
                if p.exists():
                    if p.is_file():
                        files.append(p)
                    elif p.is_dir():
                        for f in p.rglob('*'):
                            if f.is_file():
                                files.append(f)
            else:
                for p in self.workspace.glob(pattern):
                    if p.is_file():
                        files.append(p)
        return list(set(files))
    
    def manifest(self, verbose: bool = True) -> dict:
        manifest = {
            'generated_at': datetime.now().isoformat(),
            'workspace': str(self.workspace),
            'categories': {},
            'total_files': 0,
            'total_size_bytes': 0
        }
        
        if verbose:
            print(f"\n{'='*70}")
            print(f"  CLAWOPS WORKSPACE MANIFEST")
            print(f"  {datetime.now().strftime('%Y-%m-%d %H:%M')}")
            print(f"{'='*70}\n")
        
        for category, info in self.precious_items.items():
            files = []
            total_size = 0
            
            for pattern in info['paths']:
                found = self._find_files([pattern])
                for f in found:
                    file_info = self._get_file_info(f)
                    if file_info:
                        files.append(file_info)
                        total_size += file_info['size_bytes']
            
            seen = set()
            unique_files = []
            for f in files:
                if f['path'] not in seen:
                    seen.add(f['path'])
                    unique_files.append(f)
            
            unique_files.sort(key=lambda x: x['path'])
            
            manifest['categories'][category] = {
                'description': info['description'],
                'files': unique_files,
                'file_count': len(unique_files),
                'total_size_bytes': total_size,
                'total_size_human': f"{total_size / 1024:.1f} KB" if total_size < 1048576 else f"{total_size / 1048576:.1f} MB"
            }
            
            manifest['total_files'] += len(unique_files)
            manifest['total_size_bytes'] += total_size
        
        manifest['total_size_human'] = f"{manifest['total_size_bytes'] / 1048576:.1f} MB"
        
        with open(self.manifest_file, 'w') as f:
            json.dump(manifest, f, indent=2)
        
        if verbose:
            print(f"Workspace: {self.workspace}")
            print(f"Total Size: {manifest['total_size_human']}")
            print(f"Total Files: {manifest['total_files']}\n")
            print(f"{'='*70}")
            print(f"  YOUR PRECIOUS")
            print(f"{'='*70}\n")
            
            for category, info in manifest['categories'].items():
                if info['file_count'] > 0:
                    icon = '🧠' if category in ['memory', 'progress'] else '💰' if category == 'vault' else '🛠️' if category == 'scripts' else '📦'
                    print(f"{icon} {info['description'].upper()}")
                    print(f"   Files: {info['file_count']} | Size: {info['total_size_human']}")
                    
                    for f in info['files'][:5]:
                        print(f"   ├── {f['path']}")
                    if len(info['files']) > 5:
                        print(f"   └── ... and {len(info['files']) - 5} more")
                    print()
            
            print(f"{'='*70}\n")
            print(f"📁 Manifest saved to: {self.manifest_file}")
        
        return manifest
    
    def snapshot(self, verbose: bool = True) -> dict:
        manifest = self.manifest(verbose=False)
        
        timestamp = datetime.now().strftime('%Y%m%d-%H%M%S')
        snapshot_name = f'clawops-snapshot-{timestamp}.tar.gz'
        snapshot_path = self.snapshot_dir / snapshot_name
        
        if verbose:
            print(f"\n{'='*70}")
            print(f"  CREATING WORKSPACE SNAPSHOT")
            print(f"  {datetime.now().strftime('%Y-%m-%d %H:%M')}")
            print(f"{'='*70}\n")
        
        files_added = 0
        
        with tarfile.open(snapshot_path, 'w:gz') as tar:
            for category, info in manifest['categories'].items():
                for file_info in info['files']:
                    file_path = self.workspace / file_info['path']
                    
                    if file_path.exists():
                        try:
                            tar.add(file_path, arcname=file_info['path'])
                            files_added += 1
                            
                            if verbose and files_added <= 20:
                                print(f"   📦 {file_info['path']}")
                            elif verbose and files_added == 21:
                                print(f"   ... and {manifest['total_files'] - 20} more files")
                        except Exception as e:
                            if verbose:
                                print(f"   ⚠️  Skipped: {file_info['path']}: {e}")
        
        snapshot_info = {
            'snapshot_file': str(snapshot_path),
            'created_at': datetime.now().isoformat(),
            'workspace': str(self.workspace),
            'files_included': files_added,
            'total_size_bytes': snapshot_path.stat().st_size,
            'manifest': manifest,
            'checksum': self._calculate_checksum(snapshot_path)
        }
        
        metadata_path = snapshot_path.with_suffix('.meta.json')
        with open(metadata_path, 'w') as f:
            json.dump(snapshot_info, f, indent=2)
        
        registry = self._load_registry()
        registry['snapshots'].append({
            'file': str(snapshot_path),
            'metadata': str(metadata_path),
            'created_at': snapshot_info['created_at'],
            'files': files_added,
            'size_bytes': snapshot_info['total_size_bytes'],
            'checksum': snapshot_info['checksum']
        })
        self._save_registry(registry)
        
        if verbose:
            print(f"\n{'='*70}")
            print(f"  ✅ SNAPSHOT CREATED!")
            print(f"{'='*70}")
            print(f"\n📁 File: {snapshot_path}")
            print(f"📊 Size: {snapshot_info['total_size_bytes'] / 1048576:.1f} MB")
            print(f"📦 Files: {files_added}")
            print(f"🔐 Checksum: {snapshot_info['checksum'][:16]}...")
            print(f"\n💾 Your Precious is safe!\n")
        
        return snapshot_info
    
    def _load_registry(self) -> dict:
        registry_file = self.workspace / '.snapshot_registry.json'
        if registry_file.exists():
            with open(registry_file) as f:
                return json.load(f)
        return {'snapshots': []}
    
    def _save_registry(self, registry: dict):
        registry_file = self.workspace / '.snapshot_registry.json'
        with open(registry_file, 'w') as f:
            json.dump(registry, f, indent=2)
    
    def list_snapshots(self, verbose: bool = True) -> list:
        registry = self._load_registry()
        
        if verbose:
            print(f"\n{'='*70}")
            print(f"  WORKSPACE SNAPSHOTS")
            print(f"{'='*70}\n")
            
            if not registry['snapshots']:
                print("No snapshots found. Run --snapshot to create one.")
                return []
            
            for i, snap in enumerate(reversed(registry['snapshots']), 1):
                created = datetime.fromisoformat(snap['created_at'])
                size_mb = snap['size_bytes'] / 1048576
                
                print(f"{i}. {created.strftime('%Y-%m-%d %H:%M')}")
                print(f"   Files: {snap['files']} | Size: {size_mb:.1f} MB")
                print(f"   Path: {snap['file']}\n")
            
            print(f"Total: {len(registry['snapshots'])} snapshots\n")
        
        return registry['snapshots']
    
    def restore(self, snapshot: str = None, verbose: bool = True) -> dict:
        registry = self._load_registry()
        
        if not registry['snapshots']:
            raise ValueError("No snapshots found")
        
        if snapshot == 'latest' or snapshot is None:
            snap_info = registry['snapshots'][-1]
        else:
            for snap in registry['snapshots']:
                if snapshot in snap_info['file']:
                    snap_info = snap
                    break
            else:
                raise ValueError(f"Snapshot not found: {snapshot}")
        
        if verbose:
            print(f"\n{'='*70}")
            print(f"  RESTORING WORKSPACE")
            print(f"{'='*70}\n")
            print(f"📁 From: {snap_info['file']}")
            print(f"📦 Files: {snap_info['files']}\n")
        
        # Create safety backup
        if verbose:
            print("💾 Creating safety backup...")
        
        safety_name = f'safety-backup-{datetime.now().strftime("%Y%m%d-%H%M%S")}.tar.gz'
        safety_path = self.snapshot_dir / safety_name
        
        try:
            with open(snap_info['metadata']) as f:
                meta = json.load(f)
                files_to_backup = []
                for category, info in meta['manifest']['categories'].items():
                    for f_info in info['files']:
                        f_path = self.workspace / f_info['path']
                        if f_path.exists():
                            files_to_backup.append(f_path)
            
            if files_to_backup:
                with tarfile.open(safety_path, 'w:gz') as tar:
                    for f in files_to_backup[:100]:
                        try:
                            tar.add(f, arcname=str(f.relative_to(self.workspace)))
                        except:
                            pass
                
                if verbose:
                    print(f"   ✅ Safety backup: {safety_path.name}")
        except Exception as e:
            if verbose:
                print(f"   ⚠️  Safety backup skipped: {e}")
        
        # Extract snapshot
        if verbose:
            print(f"\n📦 Extracting snapshot...")
        
        extracted = 0
        try:
            with tarfile.open(snap_info['file'], 'r:gz') as tar:
                for member in tar.getmembers():
                    target = self.workspace / member.name
                    target.parent.mkdir(parents=True, exist_ok=True)
                    
                    if member.isfile():
                        tar.extract(member, path=self.workspace)
                        extracted += 1
                        
                        if verbose and extracted <= 10:
                            print(f"   📄 {member.name}")
                    elif member.isdir():
                        target.mkdir(parents=True, exist_ok=True)
            
            if verbose and extracted > 10:
                print(f"   ... and {extracted - 10} more files")
                
        except Exception as e:
            if verbose:
                print(f"❌ Restore failed: {e}")
            return {'success': False, 'error': str(e)}
        
        if verbose:
            print(f"\n{'='*70}")
            print(f"  ✅ WORKSPACE RESTORED!")
            print(f"{'='*70}")
            print(f"\n📦 Files restored: {extracted}")
            if safety_path.exists():
                print(f"💾 Safety backup: {safety_path}")
            print(f"\n⚠️  Git may need: git checkout . && git pull\n")
        
        return {'success': True, 'files_restored': extracted, 'safety_backup': str(safety_path)}
    
    def quick_snapshot(self):
        result = subprocess.run(
            ['git', 'rev-parse', 'HEAD'],
            cwd=self.workspace,
            capture_output=True,
            text=True
        )
        commit = result.stdout.strip()[:8] if result.returncode == 0 else 'unknown'
        
        self.snapshot(verbose=True)
        
        print(f"\n🚀 Git commit: {commit}")


def main():
    parser = argparse.ArgumentParser(
        description='ClawOps Workspace Preserver - Protect Your Precious!'
    )
    
    parser.add_argument('--snapshot', action='store_true', help='Create snapshot')
    parser.add_argument('--manifest', action='store_true', help='Generate manifest')
    parser.add_argument('--list', action='store_true', help='List snapshots')
    parser.add_argument('--restore', type=str, metavar='SNAPSHOT', help='Restore')
    parser.add_argument('--quick', action='store_true', help='Quick snapshot')
    parser.add_argument('--workspace', type=str, help='Path to workspace')
    
    args = parser.parse_args()
    
    preserver = WorkspacePreserver(args.workspace)
    
    if args.manifest:
        preserver.manifest()
    elif args.snapshot:
        preserver.snapshot()
    elif args.quick:
        preserver.quick_snapshot()
    elif args.list:
        preserver.list_snapshots()
    elif args.restore:
        preserver.restore(args.restore)
    else:
        print("""
🏠 ClawOps Workspace Preserver

Your Precious — everything that makes ClawOps, ClawOps.

Usage:
    python3 workspace_preserver.py --manifest      # See what's precious
    python3 workspace_preserver.py --snapshot     # Create snapshot
    python3 workspace_preserver.py --list          # List snapshots
    python3 workspace_preserver.py --restore latest  # Restore

Cron (Daily at 3 AM):
    0 3 * * * python3 workspace_preserver.py --quick
""")


if __name__ == '__main__':
    main()
