#!/usr/bin/env python3
"""
Client Vault Manager — Secure Client Onboarding System
======================================================

Manages client credentials, tokens, and setup details with self-lockout prevention.

Philosophy:
- ClawOps (Master) has FULL ACCESS always
- Clients have CONTROLLED ACCESS via tokens
- Memory/Context is ALWAYS MUTABLE (agent brain)
- Core System is IMMUTABLE (DENY ALL)

Usage:
    python3 client_vault.py --add-client --name "acme-corp" --email "admin@acme.com"
    python3 client_vault.py --list-clients
    python3 client_vault.py --generate-access --client "acme-corp" --type "client"
    python3 client_vault.py --generate-access --client "acme-corp" --type "master"
"""

import argparse
import json
import secrets
import hashlib
import os
import stat
from datetime import datetime, timedelta
from pathlib import Path
from enum import Enum


class TokenType(Enum):
    """Types of tokens for different access levels."""
    MASTER = "master"  # ClawOps only - full permanent access
    CLIENT_EDIT = "client_edit"  # Client - single-use, time-limited
    READONLY = "readonly"  # Auditors - read-only access


class ClientVault:
    """
    Secure client vault with multi-layer access control.
    
    Structure:
    /opt/clawops/vault/
    ├── clients/
    │   └── [client-id]/
    │       ├── client.yaml       (Client config)
    │       ├── credentials.yaml  (Encrypted credentials)
    │       └── tokens.json       (Token tracking)
    ├── master_token              (ClawOps master key)
    └── vault_status.json         (Vault health)
    """
    
    VAULT_PATH = Path('/opt/clawops/vault')
    MASTERS_PATH = VAULT_PATH / 'masters'
    CLIENTS_PATH = VAULT_PATH / 'clients'
    
    def __init__(self):
        self._ensure_vault_exists()
    
    def _ensure_vault_exists(self):
        """Create vault structure if missing."""
        self.VAULT_PATH.mkdir(parents=True, exist_ok=True)
        self.MASTERS_PATH.mkdir(parents=True, exist_ok=True)
        self.CLIENTS_PATH.mkdir(parents=True, exist_ok=True)
        
        # Set restrictive permissions on vault
        os.chmod(self.VAULT_PATH, stat.S_IRWXU)  # 700 - owner only
        
        # Initialize vault status
        status_file = self.VAULT_PATH / 'vault_status.json'
        if not status_file.exists():
            self._update_status({'initialized': True, 'created_at': datetime.utcnow().isoformat()})
    
    def _update_status(self, status: dict):
        """Update vault status file."""
        status['updated_at'] = datetime.utcnow().isoformat()
        with open(self.VAULT_PATH / 'vault_status.json', 'w') as f:
            json.dump(status, f, indent=2)
    
    # ========== CLIENT MANAGEMENT ==========
    
    def add_client(self, name: str, email: str, channels: list = None, verbose: bool = True) -> dict:
        """
        Add a new client to the vault.
        
        Creates:
        - Client directory structure
        - Client config file
        - Generates master token for ClawOps
        """
        client_id = name.lower().replace(' ', '-')
        client_path = self.CLIENTS_PATH / client_id
        
        if client_path.exists():
            raise ValueError(f"Client '{name}' already exists")
        
        # Create client directory
        client_path.mkdir(parents=True, exist_ok=True)
        os.chmod(client_path, stat.S_IRWXU)  # 700
        
        # Client config
        config = {
            'id': client_id,
            'name': name,
            'email': email,
            'channels': channels or [],
            'created_at': datetime.utcnow().isoformat(),
            'status': 'active',
            'deployment': {
                'path': f'/root/.openclaw/clients/{client_id}',
                'soul_path': f'/root/.openclaw/clients/{client_id}/SOUL.md',
                'use_case_path': f'/root/.openclaw/clients/{client_id}/USE_CASES'
            }
        }
        
        with open(client_path / 'client.yaml', 'w') as f:
            json.dump(config, f, indent=2)
        
        # Empty credentials file (encrypted in production)
        credentials = {
            'encrypted': False,  # TODO: Add encryption
            'created_at': datetime.utcnow().isoformat(),
            'ai_providers': {},
            'channels': {}
        }
        
        with open(client_path / 'credentials.yaml', 'w') as f:
            json.dump(credentials, f, indent=2)
        
        # Empty token tracking
        tokens = {
            'active_tokens': [],
            'revoked_tokens': [],
            'token_history': []
        }
        
        with open(client_path / 'tokens.json', 'w') as f:
            json.dump(tokens, f, indent=2)
        
        # Generate MASTER token for this client (ClawOps keeps this)
        master_token = self._generate_token(
            client_id=client_id,
            token_type=TokenType.MASTER,
            description=f"Master token for {name}"
        )
        
        # Store master token securely
        self._store_master_token(client_id, master_token)
        
        if verbose:
            print(f"\n{'='*50}")
            print(f"  CLIENT ADDED: {name}")
            print(f"{'='*50}")
            print(f"Client ID: {client_id}")
            print(f"Email: {email}")
            print(f"Channels: {', '.join(channels) if channels else 'None'}")
            print(f"")
            print(f"🔐 MASTER TOKEN (SAVE SECURELY - CLAWOPS USE ONLY):")
            print(f"{master_token}")
            print(f"")
            print(f"⚠️  Store this in a password manager!")
            print(f"{'='*50}\n")
        
        return {
            'client_id': client_id,
            'master_token': master_token,
            'config': config
        }
    
    def list_clients(self, verbose: bool = True) -> list:
        """List all clients in the vault."""
        clients = []
        
        for path in self.CLIENTS_PATH.iterdir():
            if path.is_dir():
                config_file = path / 'client.yaml'
                if config_file.exists():
                    with open(config_file) as f:
                        config = json.load(f)
                        clients.append(config)
        
        if verbose:
            print(f"\n{'='*60}")
            print(f"  VAULTED CLIENTS ({len(clients)})")
            print(f"{'='*60}")
            
            for client in sorted(clients, key=lambda x: x['name']):
                status = client.get('status', 'unknown')
                status_icon = '🟢' if status == 'active' else '🔴'
                
                print(f"\n{status_icon} {client['name']}")
                print(f"   ID: {client['id']}")
                print(f"   Email: {client['email']}")
                print(f"   Channels: {', '.join(client.get('channels', [])) or 'None'}")
                print(f"   Created: {client['created_at'][:10]}")
            
            print(f"\n{'='*60}\n")
        
        return clients
    
    # ========== TOKEN MANAGEMENT ==========
    
    def _generate_token(self, client_id: str, token_type: TokenType, 
                        description: str = None, validity_hours: int = 1) -> str:
        """
        Generate a secure token.
        
        Token Structure:
        [client-id].[type].[random].[timestamp].[checksum]
        
        Examples:
        - acme-corp.master.A1b2C3d4E5.9999999999.abc123
        - acme-corp.client_edit.X9y8Z7w6V5.9999999999.def456
        """
        random_part = secrets.token_urlsafe(16)
        timestamp = str(int(datetime.utcnow().timestamp()))
        
        # Master tokens never expire
        if token_type == TokenType.MASTER:
            expiry = '99999999999'  # ~year 5138
        else:
            expiry = str(int((datetime.utcnow() + timedelta(hours=validity_hours)).timestamp()))
        
        token_data = f"{client_id}.{token_type.value}.{random_part}.{timestamp}.{expiry}"
        checksum = hashlib.sha256(token_data.encode()).hexdigest()[:8]
        
        token = f"{token_data}.{checksum}"
        
        return token
    
    def _validate_token(self, token: str) -> dict:
        """
        Validate a token and return its metadata.
        
        Returns:
            dict with: valid, client_id, token_type, expired, details
        """
        try:
            parts = token.split('.')
            if len(parts) != 6:
                return {'valid': False, 'error': 'Invalid token format'}
            
            client_id, token_type_str, random_part, timestamp, expiry, checksum = parts
            
            # Verify checksum
            token_data = f"{client_id}.{token_type_str}.{random_part}.{timestamp}.{expiry}"
            expected_checksum = hashlib.sha256(token_data.encode()).hexdigest()[:8]
            
            if checksum != expected_checksum:
                return {'valid': False, 'error': 'Invalid checksum'}
            
            # Check expiry (master tokens don't expire)
            if expiry != '99999999999':
                expiry_dt = datetime.fromtimestamp(int(expiry))
                if datetime.utcnow() > expiry_dt:
                    return {
                        'valid': False,
                        'error': 'Token expired',
                        'expired_at': expiry_dt.isoformat()
                    }
            
            return {
                'valid': True,
                'client_id': client_id,
                'token_type': token_type_str,
                'created_at': datetime.fromtimestamp(int(timestamp)).isoformat(),
                'expires_at': datetime.fromtimestamp(int(expiry)).isoformat() if expiry != '99999999999' else 'Never',
                'is_master': token_type_str == 'master'
            }
            
        except Exception as e:
            return {'valid': False, 'error': str(e)}
    
    def _store_master_token(self, client_id: str, token: str):
        """Store master token securely in masters directory."""
        # Store as hash only (never raw token)
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        
        master_file = self.MASTERS_PATH / f"{client_id}.hash"
        with open(master_file, 'w') as f:
            f.write(token_hash)
        
        os.chmod(master_file, stat.S_IRUSR)  # 400 - read only
    
    def verify_master_token(self, client_id: str, token: str) -> bool:
        """Verify a master token against stored hash."""
        master_file = self.MASTERS_PATH / f"{client_id}.hash"
        
        if not master_file.exists():
            return False
        
        with open(master_file) as f:
            stored_hash = f.read().strip()
        
        input_hash = hashlib.sha256(token.encode()).hexdigest()
        
        return stored_hash == input_hash
    
    def generate_client_access(self, client_id: str, access_type: str = 'edit', 
                               validity_hours: int = 1, verbose: bool = True) -> dict:
        """
        Generate access token for a client.
        
        Types:
        - 'edit': Single-use token, unlocks filesystem for editing
        - 'readonly': Read-only access to configs (no unlock)
        """
        if access_type == 'edit':
            token_type = TokenType.CLIENT_EDIT
        else:
            token_type = TokenType.READONLY
        
        token = self._generate_token(
            client_id=client_id,
            token_type=token_type,
            validity_hours=validity_hours
        )
        
        # Store token in client's tokens.json
        token_record = {
            'token': token[:32] + '...',  # Only store partial for display
            'type': token_type.value,
            'created_at': datetime.utcnow().isoformat(),
            'valid_until': (datetime.utcnow() + timedelta(hours=validity_hours)).isoformat(),
            'used': False
        }
        
        client_path = self.CLIENTS_PATH / client_id
        tokens_file = client_path / 'tokens.json'
        
        with open(tokens_file) as f:
            tokens_data = json.load(f)
        
        tokens_data['active_tokens'].append(token_record)
        tokens_data['token_history'].append({
            'action': 'generated',
            'type': token_type.value,
            'at': datetime.utcnow().isoformat()
        })
        
        with open(tokens_file, 'w') as f:
            json.dump(tokens_data, f, indent=2)
        
        if verbose:
            print(f"\n{'='*50}")
            print(f"  ACCESS TOKEN GENERATED")
            print(f"{'='*50}")
            print(f"Client: {client_id}")
            print(f"Type: {access_type}")
            print(f"Valid for: {validity_hours} hour(s)")
            print(f"")
            print(f"🔐 TOKEN:")
            print(f"{token}")
            print(f"")
            print(f"⚠️  Single-use! Use once, then relock.")
            print(f"{'='*50}\n")
        
        return {
            'token': token,
            'client_id': client_id,
            'type': access_type,
            'valid_until': token_record['valid_until']
        }
    
    # ========== CLIENT STATUS ==========
    
    def get_client_status(self, client_id: str, verbose: bool = True) -> dict:
        """Get detailed status of a client."""
        client_path = self.CLIENTS_PATH / client_id
        
        if not client_path.exists():
            raise ValueError(f"Client '{client_id}' not found")
        
        # Load all client files
        with open(client_path / 'client.yaml') as f:
            config = json.load(f)
        
        with open(client_path / 'tokens.json') as f:
            tokens = json.load(f)
        
        status = {
            'config': config,
            'tokens': {
                'active': len(tokens['active_tokens']),
                'revoked': len(tokens['revoked_tokens'])
            },
            'deployment': {
                'exists': Path(config['deployment']['path']).exists(),
                'soul_exists': Path(config['deployment']['soul_path']).exists(),
                'immutable': self._check_immutability_status(config['deployment']['path'])
            }
        }
        
        if verbose:
            print(f"\n{'='*50}")
            print(f"  CLIENT STATUS: {config['name']}")
            print(f"{'='*50}")
            print(f"ID: {config['id']}")
            print(f"Status: {config['status']}")
            print(f"Email: {config['email']}")
            print(f"")
            print(f"Deployment:")
            print(f"  Path: {config['deployment']['path']}")
            print(f"  Soul: {config['deployment']['soul_path']}")
            print(f"")
            print(f"Tokens:")
            print(f"  Active: {status['tokens']['active']}")
            print(f"  Revoked: {status['tokens']['revoked']}")
            print(f"{'='*50}\n")
        
        return status
    
    def _check_immutability_status(self, path: str) -> dict:
        """Check immutability status of a deployment."""
        lock_file = Path('/opt/clawops/.immutability_status.json')
        
        if not lock_file.exists():
            return {'status': 'unknown'}
        
        with open(lock_file) as f:
            data = json.load(f)
        
        return {
            'status': data.get('status', 'unknown'),
            'locked_at': data.get('locked_at', 'unknown')
        }


def main():
    parser = argparse.ArgumentParser(
        description='Client Vault Manager — Secure Client Onboarding'
    )
    
    # Client management
    parser.add_argument(
        '--add-client',
        action='store_true',
        help='Add a new client to the vault'
    )
    parser.add_argument(
        '--name',
        type=str,
        help='Client name (e.g., "Acme Corp")'
    )
    parser.add_argument(
        '--email',
        type=str,
        help='Client admin email'
    )
    parser.add_argument(
        '--channels',
        type=str,
        help='Comma-separated channels (e.g., "Telegram,Slack")'
    )
    
    # Listing
    parser.add_argument(
        '--list-clients',
        action='store_true',
        help='List all vaulted clients'
    )
    
    # Token management
    parser.add_argument(
        '--generate-access',
        action='store_true',
        help='Generate access token for a client'
    )
    parser.add_argument(
        '--client',
        type=str,
        help='Client ID'
    )
    parser.add_argument(
        '--type',
        type=str,
        default='edit',
        choices=['edit', 'readonly'],
        help='Access type'
    )
    parser.add_argument(
        '--validity',
        type=int,
        default=1,
        help='Token validity in hours'
    )
    
    # Status
    parser.add_argument(
        '--status',
        type=str,
        help='Get status of a specific client'
    )
    
    vault = ClientVault()
    
    if args := parser.parse_args():
        try:
            if args.add_client and args.name:
                vault.add_client(
                    name=args.name,
                    email=args.email or f"admin@{args.name.lower().replace(' ', '')}.com",
                    channels=args.channels.split(',') if args.channels else []
                )
            
            elif args.list_clients:
                vault.list_clients()
            
            elif args.generate_access and args.client:
                vault.generate_client_access(
                    client_id=args.client,
                    access_type=args.type,
                    validity_hours=args.validity
                )
            
            elif args.status:
                vault.get_client_status(args.status)
            
            else:
                parser.print_help()
                
        except Exception as e:
            print(f"❌ Error: {e}")
            return 1
    
    return 0


if __name__ == '__main__':
    exit(main())
