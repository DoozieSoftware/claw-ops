#!/usr/bin/env python3
"""
SOUL Validator Script
=====================

Validates actions against the client's SOUL.md configuration.
DENY ALL by default — if it's not explicitly allowed, it's BLOCKED.

Usage:
    python3 soul_validator.py --soul /path/to/SOUL.md --action "query-emails" --user "user@client.com" --channel "Telegram"
    python3 soul_validator.py --test-all --soul /path/to/SOUL.md
"""

import argparse
import json
import sys
import yaml
from datetime import datetime, time
from pathlib import Path


class SoulValidator:
    """
    SOUL Validation Engine
    
    Validates every action against the SOUL.md configuration before execution.
    Returns (is_allowed, errors) tuple.
    """
    
    def __init__(self, soul_path: str):
        with open(soul_path) as f:
            self.soul = yaml.safe_load(f)
        self.name = self.soul.get('Identity', {}).get('Bot Name', 'Unknown')
        self.use_cases = self._load_use_cases()
    
    def _load_use_cases(self) -> dict:
        """Load all approved use cases from USE_CASES folder."""
        use_cases = {}
        use_case_dir = Path(self.soul.get('_meta', {}).get('use_case_path', './USE_CASES'))
        
        if use_case_dir.exists():
            for md_file in use_case_dir.glob('*.md'):
                with open(md_file) as f:
                    content = yaml.safe_load(f)
                    if content:
                        use_cases[content.get('name')] = content
        
        return use_cases
    
    def validate_action(self, user: str, channel: str, action: str, 
                       data: dict = None, time_now: datetime = None) -> tuple:
        """
        Main validation function.
        
        Returns (is_allowed: bool, errors: list)
        """
        errors = []
        
        # 1. CHANNEL Check
        channel_allowed = self._check_channel(channel)
        if not channel_allowed:
            errors.append(f"CHANNEL_BLOCKED: {channel} is not in allowlist")
        
        # 2. USER Check
        user_allowed = self._check_user(user)
        if not user_allowed:
            errors.append(f"USER_NOT_ALLOWED: {user} is not in allowlist")
        
        # 3. ACTION Check (Core DENY ALL check)
        action_allowed = self._check_action(action)
        if not action_allowed:
            errors.append(f"ACTION_BLOCKED: '{action}' is not in allowed use cases")
        
        # 4. TIME Check
        if time_now:
            time_ok = self._check_time(time_now)
            if not time_ok:
                errors.append("TIME_BLOCKED: Outside active hours")
        
        # 5. DATA Check
        if data:
            data_ok = self._check_data(data)
            if not data_ok:
                errors.append(f"DATA_BLOCKED: {data.get('error', 'Unknown data violation')}")
        
        # 6. HIGH RISK Check
        high_risk_ok = self._check_high_risk(action)
        if not high_risk_ok:
            errors.append("HIGH_RISK_BLOCKED: Action requires extra validation")
        
        return len(errors) == 0, errors
    
    def _check_channel(self, channel: str) -> bool:
        """Check if channel is in SOUL allowlist."""
        boundaries = self.soul.get('Boundaries', {})
        allowed = boundaries.get('Channels', {}).get('ALLOWED', [])
        blocked = boundaries.get('Channels', {}).get('BLOCKED', [])
        
        # Explicit allowlist takes precedence
        if allowed:
            return channel in allowed
        
        # Otherwise check if it's not blocked
        return channel not in blocked
    
    def _check_user(self, user: str) -> bool:
        """Check if user is in allowlist."""
        access = self.soul.get('User Access', {})
        allowed_users = access.get('Allowlist', [])
        
        # Check exact match first
        if user in allowed_users:
            return True
        
        # Check if user has access to this channel
        user_access = access.get(user, {})
        allowed_channels = user_access.get('channels', [])
        if allowed_channels:
            return True
        
        return False
    
    def _check_action(self, action: str) -> bool:
        """
        CORE DENY ALL CHECK
        
        Actions must be in an APPROVED USE CASE to be allowed.
        """
        boundaries = self.soul.get('Boundaries', {})
        allowed_actions = boundaries.get('Actions', {}).get('ALLOWED', [])
        blocked_actions = boundaries.get('Actions', {}).get('BLOCKED', [])
        
        # If action is explicitly blocked, deny
        if action in blocked_actions:
            return False
        
        # If allowed list is specified, check it
        if allowed_actions:
            return action in allowed_actions
        
        # DENY ALL fallback — check if action is in an approved use case
        return self._action_in_approved_use_case(action)
    
    def _action_in_approved_use_case(self, action: str) -> bool:
        """Check if action is part of any approved use case."""
        # Get list of allowed use case names
        use_case_names = self.soul.get('Use Cases', {}).get('ALLOWED', [])
        
        for uc_name in use_case_names:
            if uc_name in self.use_cases:
                uc = self.use_cases[uc_name]
                allowed = uc.get('Actions', {}).get('ALLOWED', [])
                if action in allowed:
                    return True
        
        return False
    
    def _check_time(self, time_now: datetime) -> bool:
        """Check if current time is within active hours."""
        boundaries = self.soul.get('Time Boundaries', {})
        active_hours = boundaries.get('ACTIVE', '9:00-19:00')
        
        # Parse active hours
        try:
            start_str, end_str = active_hours.split('-')
            start_hour = int(start_str.split(':')[0])
            end_hour = int(end_str.split(':')[0])
            current_hour = time_now.hour
            return start_hour <= current_hour < end_hour
        except:
            # If parsing fails, default to DENY
            return False
    
    def _check_data(self, data: dict) -> bool:
        """Check if data is within defined limits."""
        boundaries = self.soul.get('Boundaries', {})
        limits = boundaries.get('Data Boundaries', {})
        
        # Check attachment size
        if 'attachment_size' in data:
            max_size = limits.get('Attachment Size', '10MB')
            max_bytes = self._parse_size(max_size)
            if data['attachment_size'] > max_bytes:
                return False
        
        # Check for prohibited operations
        prohibited = limits.get('Prohibited Operations', [])
        for op in prohibited:
            if op.lower() in data.get('type', '').lower():
                return False
        
        return True
    
    def _check_high_risk(self, action: str) -> bool:
        """Check if action is high-risk and requires extra validation."""
        # Check SOUL's high-risk list
        high_risk = self.soul.get('Safety Guards', {}).get('HIGH_RISK_ACTIONS', [])
        if action in high_risk:
            return False
        
        # Check each use case's high-risk list
        use_case_names = self.soul.get('Use Cases', {}).get('ALLOWED', [])
        for uc_name in use_case_names:
            if uc_name in self.use_cases:
                uc = self.use_cases[uc_name]
                uc_high_risk = uc.get('Actions', {}).get('HIGH_RISK', [])
                if action in uc_high_risk:
                    return False
        
        return True
    
    def _parse_size(self, size_str: str) -> int:
        """Parse size string (e.g., '10MB') to bytes."""
        multipliers = {
            'B': 1,
            'KB': 1024,
            'MB': 1024**2,
            'GB': 1024**3,
        }
        size_str = size_str.upper().strip()
        for unit, mult in multipliers.items():
            if size_str.endswith(unit):
                return int(size_str[:-len(unit)]) * mult
        return int(size_str)
    
    def get_allowed_actions(self, user: str = None) -> list:
        """Get list of all allowed actions for a user."""
        all_allowed = set()
        
        # Add from SOUL boundaries
        boundaries = self.soul.get('Boundaries', {})
        allowed = boundaries.get('Actions', {}).get('ALLOWED', [])
        all_allowed.update(allowed)
        
        # Add from approved use cases
        use_case_names = self.soul.get('Use Cases', {}).get('ALLOWED', [])
        for uc_name in use_case_names:
            if uc_name in self.use_cases:
                uc = self.use_cases[uc_name]
                uc_allowed = uc.get('Actions', {}).get('ALLOWED', [])
                all_allowed.update(uc_allowed)
        
        return sorted(list(all_allowed))
    
    def get_blocked_actions(self) -> list:
        """Get list of explicitly blocked actions."""
        boundaries = self.soul.get('Boundaries', {})
        return boundaries.get('Actions', {}).get('BLOCKED', [])
    
    def generate_report(self) -> dict:
        """Generate validation status report."""
        return {
            'bot_name': self.name,
            'use_cases_enabled': self.soul.get('Use Cases', {}).get('ALLOWED', []),
            'allowed_actions': self.get_allowed_actions(),
            'blocked_actions': self.get_blocked_actions(),
            'total_allowed': len(self.get_allowed_actions()),
            'total_blocked': len(self.get_blocked_actions()),
            'validation_mode': 'DENY_ALL'
        }


def test_all_use_cases(validator: SoulValidator) -> bool:
    """Test all use cases in the SOUL configuration."""
    print(f"\n{'='*60}")
    print(f"Testing SOUL Configuration: {validator.name}")
    print(f"{'='*60}\n")
    
    use_cases = validator.soul.get('Use Cases', {}).get('ALLOWED', [])
    
    if not use_cases:
        print("⚠️  No use cases enabled. All actions will be BLOCKED.")
        return False
    
    print(f"Enabled Use Cases: {len(use_cases)}")
    for uc in use_cases:
        print(f"  ✅ {uc}")
    
    print(f"\nAllowed Actions: {len(validator.get_allowed_actions())}")
    for action in validator.get_allowed_actions():
        print(f"  ✅ {action}")
    
    print(f"\nExplicitly Blocked Actions: {len(validator.get_blocked_actions())}")
    for action in validator.get_blocked_actions():
        print(f"  ⛔ {action}")
    
    print(f"\n{'-'*60}")
    print("Test Scenarios:")
    print(f"{'-'*60}")
    
    # Test scenarios
    scenarios = [
        {
            'name': 'Allowed Action',
            'user': 'user1@client.com',
            'channel': 'Telegram',
            'action': 'query-emails',
            'expected': True
        },
        {
            'name': 'Blocked Channel',
            'user': 'user1@client.com',
            'channel': 'WhatsApp',
            'action': 'query-emails',
            'expected': False
        },
        {
            'name': 'Blocked Action',
            'user': 'user1@client.com',
            'channel': 'Telegram',
            'action': 'delete-emails',
            'expected': False
        },
        {
            'name': 'Unlisted User',
            'user': 'unknown@external.com',
            'channel': 'Telegram',
            'action': 'query-emails',
            'expected': False
        }
    ]
    
    all_passed = True
    for scenario in scenarios:
        allowed, errors = validator.validate_action(
            scenario['user'],
            scenario['channel'],
            scenario['action']
        )
        
        status = "✅ PASS" if allowed == scenario['expected'] else "❌ FAIL"
        if allowed != scenario['expected']:
            all_passed = False
        
        print(f"\n{scenario['name']}:")
        print(f"  User: {scenario['user']}")
        print(f"  Channel: {scenario['channel']}")
        print(f"  Action: {scenario['action']}")
        print(f"  Expected: {scenario['expected']} | Got: {allowed}")
        print(f"  Result: {status}")
        
        if errors:
            print(f"  Errors: {', '.join(errors)}")
    
    print(f"\n{'='*60}")
    if all_passed:
        print("✅ ALL TESTS PASSED — SOUL configuration is valid")
    else:
        print("❌ SOME TESTS FAILED — Review SOUL configuration")
    print(f"{'='*60}\n")
    
    return all_passed


def main():
    parser = argparse.ArgumentParser(
        description='SOUL Validator — Validates actions against SOUL.md configuration'
    )
    parser.add_argument(
        '--soul', 
        type=str, 
        required=True,
        help='Path to SOUL.md file'
    )
    parser.add_argument(
        '--user',
        type=str,
        required=False,
        help='User to validate'
    )
    parser.add_argument(
        '--channel',
        type=str,
        required=False,
        help='Channel to validate'
    )
    parser.add_argument(
        '--action',
        type=str,
        required=False,
        help='Action to validate'
    )
    parser.add_argument(
        '--test-all',
        action='store_true',
        help='Run full validation test suite'
    )
    parser.add_argument(
        '--report',
        action='store_true',
        help='Generate SOUL configuration report'
    )
    
    args = parser.parse_args()
    
    # Validate soul file exists
    if not Path(args.soul).exists():
        print(f"❌ SOUL file not found: {args.soul}")
        sys.exit(1)
    
    try:
        validator = SoulValidator(args.soul)
        
        if args.test_all:
            success = test_all_use_cases(validator)
            sys.exit(0 if success else 1)
        
        if args.report:
            report = validator.generate_report()
            print(json.dumps(report, indent=2))
            sys.exit(0)
        
        if args.action and args.user and args.channel:
            allowed, errors = validator.validate_action(
                args.user,
                args.channel,
                args.action
            )
            
            if allowed:
                print(f"✅ ALLOWED: {args.action}")
                print(f"   User: {args.user}")
                print(f"   Channel: {args.channel}")
                sys.exit(0)
            else:
                print(f"⛔ BLOCKED: {args.action}")
                print(f"   User: {args.user}")
                print(f"   Channel: {args.channel}")
                print(f"   Reasons:")
                for error in errors:
                    print(f"     - {error}")
                sys.exit(1)
        
        else:
            parser.print_help()
            
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
