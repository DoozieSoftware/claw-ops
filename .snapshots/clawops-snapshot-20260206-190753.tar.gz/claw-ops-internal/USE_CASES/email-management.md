# Email Management Use Case

> **Use Case:** email-management  
> **Version:** 1.0.0  
> **Description:** Query, search, and summarize emails. Read-only by default.  
> **Risk Level:** LOW (Read-only operations)

---

## Overview

This use case enables users to query their mailbox via approved channels. All operations are **read-only** by default. Any write actions (drafting, sending) require explicit approval in SOUL.md.

### What Users Can Do

| Action | Description | Risk |
|--------|-------------|------|
| `query-emails` | Get recent emails | Low |
| `search-emails` | Search by sender/subject | Low |
| `summarize-emails` | AI summary of email threads | Low |
| `get-attachment` | Download attachment (≤5MB) | Medium |

### What Users CANNOT Do

| Action | Reason |
|--------|--------|
| `delete-emails` | Data safety — BLOCKED |
| `send-emails` | Write action — Requires separate use case |
| `forward-emails` | External risk — BLOCKED |
| `bulk-delete` | High risk — BLOCKED |

---

## Channels

| Channel | Status | Notes |
|---------|--------|-------|
| Telegram | ✅ Allowed | Group chat only |
| Slack | ✅ Allowed | Channel only |
| WhatsApp | ❌ Not enabled | Future |
| Discord | ❌ Not enabled | Future |

---

## Permissions Required

| Permission | Source | Purpose |
|------------|--------|---------|
| `email.read` | Gmail/IMAP | Read email metadata |
| `email.search` | Gmail/IMAP | Search functionality |
| `attachment.read` | Gmail/IMAP | Download attachments |

---

## Actions

### Allowed Actions

```yaml
- query-emails
- search-emails
- summarize-emails
- get-attachment
```

### Blocked Actions

```yaml
- delete-emails
- send-emails
- forward-emails
- reply-emails
- draft-emails
```

### High-Risk Actions (Require Admin Approval)

```yaml
- bulk-delete
- bulk-forward
- download-all-attachments
```

---

## Limits

| Limit | Value | Notes |
|-------|-------|-------|
| Max results | 50 emails | Per query |
| Attachment size | 5MB | Per file |
| Rate limit | 10/minute | Per user |
| Query span | 90 days | Default |

---

## Validation Rules

Before executing any email action:

1. ✅ Check user is in SOUL allowlist
2. ✅ Check channel is approved
3. ✅ Check attachment size ≤ 5MB
4. ✅ Check action is in ALLOWED list
5. ✅ Check time is within ACTIVE hours

---

## Example User Prompts

| Prompt | Action Triggered |
|--------|-----------------|
| "Show my unread emails" | `query-emails` |
| "Find emails from John about the project" | `search-emails` |
| "Summarize the last 5 emails from HR" | `summarize-emails` |
| "Get the PDF attachment from that email" | `get-attachment` |

---

## Required Skills

| Skill | Version | Purpose |
|-------|---------|---------|
| `email-query` | 1.0+ | Core email retrieval |
| `email-search` | 1.0+ | Search functionality |
| `email-summarize` | 1.0+ | AI summarization |

---

## Audit Tags

- `email`
- `read-only`
- `no-delete`

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2026-02-06 | Initial version |

---

*This use case is DENY ALL. Only actions listed in ALLOWED are permitted. All other actions are BLOCKED.*
