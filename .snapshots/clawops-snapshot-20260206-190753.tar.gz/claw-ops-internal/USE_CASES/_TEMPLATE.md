# Use Case Template

> **Template for creating new use cases. Copy this file to USE_CASES/ folder.**

```yaml
---
name: "use-case-name"
version: "1.0.0"
created: "YYYY-MM-DD"
author: "ClawOps"

description: |
  Brief description of what this use case does.

channels:
  - "Telegram"
  - "Slack"
  # Add channels this use case supports

permissions:
  required:
    - "email.read"
    - "calendar.read"
  optional: []

actions:
  ALLOWED:
    - "query-emails"
    - "search-emails"
    - "summarize-emails"
  
  BLOCKED:
    - "delete-emails"
    - "send-external"
    - "download-attachments"
  
  HIGH_RISK:
    - "bulk-delete"
    - "forward-external"

limits:
  max_results: 50
  max_attachment_size: "5MB"
  rate_limit: "10/minute"

validation:
  - Check attachment size < 5MB
  - Check user is in allowlist
  - Check action is in ALLOWED list

example_prompts:
  - "Show my unread emails"
  - "Find emails from John about the project"
  - "Summarize emails from last week"

required_skills:
  - "email-query"
  - "email-summarize"

audit_tags:
  - "email"
  - "read-only"
---
