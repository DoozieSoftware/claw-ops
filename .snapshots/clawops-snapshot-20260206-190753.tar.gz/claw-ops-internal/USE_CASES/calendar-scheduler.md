# Calendar Scheduling Use Case

> **Use Case:** calendar-scheduler  
> **Version:** 1.0.0  
> **Description:** Schedule meetings and check availability.  
> **Risk Level:** MEDIUM (Write operations)

---

## Overview

This use case enables users to schedule meetings and check calendar availability via approved channels.

### What Users Can Do

| Action | Description | Risk |
|--------|-------------|------|
| `check-availability` | Check free/busy slots | Low |
| `get-events` | List upcoming events | Low |
| `create-event` | Schedule new meeting | Medium |
| `update-event` | Modify meeting details | Medium |

### What Users CANNOT Do

| Action | Reason |
|--------|--------|
| `delete-event` | Data safety — BLOCKED |
| `cancel-event` | Requires approval — BLOCKED |
| `invite-external` | External risk — BLOCKED |

---

## Channels

| Channel | Status | Notes |
|---------|--------|-------|
| Telegram | ✅ Allowed | Group chat only |
| Slack | ✅ Allowed | Channel only |
| WhatsApp | ❌ Not enabled | Future |
| Discord | ❌ Not enabled | Future |

---

## Permissions Required

| Permission | Source | Purpose |
|------------|--------|---------|
| `calendar.read` | Google/Outlook API | Read events |
| `calendar.write` | Google/Outlook API | Create/modify events |

---

## Actions

### Allowed Actions

```yaml
- check-availability
- get-events
- create-event
- update-event
```

### Blocked Actions

```yaml
- delete-event
- cancel-event
- invite-external
- delete-all-events
```

### High-Risk Actions (Require Admin Approval)

```yaml
- bulk-delete
- modify-recurring
- invite-100+
```

---

## Limits

| Limit | Value | Notes |
|-------|-------|-------|
| Max events | 100 | Per query |
| Meeting duration | 4 hours | Default max |
| Attendees | 50 | Per meeting |
| Rate limit | 10/minute | Per user |

---

## Validation Rules

Before executing any calendar action:

1. ✅ Check user is in SOUL allowlist
2. ✅ Check channel is approved
3. ✅ Check attendees ≤ 50
4. ✅ Check meeting duration ≤ 4 hours
5. ✅ Check action is in ALLOWED list
6. ✅ Check time is within ACTIVE hours

---

## Example User Prompts

| Prompt | Action Triggered |
|--------|-----------------|
| "Am I free tomorrow at 2 PM?" | `check-availability` |
| "Show my meetings for next week" | `get-events` |
| "Book a meeting with John on Tuesday at 10 AM" | `create-event` |
| "Move that meeting to 3 PM" | `update-event` |

---

## Required Skills

| Skill | Version | Purpose |
|-------|---------|---------|
| `calendar-read` | 1.0+ | Read events/availability |
| `calendar-write` | 1.0+ | Create/modify events |

---

## Audit Tags

- `calendar`
- `scheduling`
- `limited-write`

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2026-02-06 | Initial version |

---

*This use case is DENY ALL. Only actions listed in ALLOWED are permitted. All other actions are BLOCKED.*
