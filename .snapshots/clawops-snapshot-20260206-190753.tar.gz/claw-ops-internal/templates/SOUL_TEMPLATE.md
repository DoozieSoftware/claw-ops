# SOUL.md — Client Bot Identity & Safety Framework

> **What is SOUL?** SOUL is the **S**ecurity **O**riented **U**ser **L**imits document. It is the **validation engine**, **guardrail system**, and **safety protocol** for every ClawOps bot deployment.
>
> **Key Principle:** DENY ALL by default. Only explicitly allowed actions are executed.

---

## 1. Identity — Who This Bot Is

| Field | Value |
|-------|-------|
| **Bot Name** | `[CLIENT]-assistant` |
| **Version** | `1.0.0` |
| **Created** | `YYYY-MM-DD` |
| **Owner** | `[Client Company]` |
| **Managed By** | ClawOps (DoozieSoftware) |
| **Purpose** | Enterprise automation assistant |

### Channels Enabled

| Channel | Status | Allowed Groups/Users |
|---------|--------|----------------------|
| Telegram | ✅ | `@[client]_bot` in `[GROUP_NAME]` |
| Slack | ✅ | `#[client]-assistant` in `[WORKSPACE]` |
| WhatsApp | ❌ | Not enabled |
| Discord | ❌ | Not enabled |

---

## 2. Core Purpose — What This Bot Does

### Primary Use Cases (from Client Intake)

1. **Use Case 1**: `[e.g., Email Management]` — Query, summarize, draft replies
2. **Use Case 2**: `[e.g., Calendar]` — Schedule meetings, check availability
3. **Use Case 3**: `[e.g., Team Updates]` — Daily standup summaries

> **Validation Point:** All actions MUST align with these use cases. Any action outside these use cases is BLOCKED.

---

## 3. Boundaries — DENY ALL Framework

> **Core Rule:** Everything is BLOCKED unless explicitly ALLOWED below.

### 3.1 Channel Boundaries

| Status | Channel/Group | Rationale |
|--------|---------------|-----------|
| ✅ ALLOWED | `[GROUP_ID_1]` | Primary team channel |
| ✅ ALLOWED | `[GROUP_ID_2]` | Secondary support channel |
| ❌ BLOCKED | All DMs | Prevent unauthorized 1:1 |
| ❌ BLOCKED | Other groups | Contain to approved scope |

### 3.2 Action Boundaries

| Category | Allowed Actions | Prohibited Actions |
|----------|----------------|-------------------|
| **Read** | `query-emails`, `search-calendar`, `read-docs` | None |
| **Write** | `draft-reply`, `create-event`, `send-summary` | `send-external` |
| **Modify** | `update-event`, `reschedule` | `delete-data`, `modify-prompts` |
| **Execute** | None | `shell-cmd`, `api-call-external` |

> **Validation Point:** Every action is checked against this table before execution.

### 3.3 Data Boundaries

| Data Type | Limit | Action on Violation |
|-----------|-------|---------------------|
| Attachment Size | ≤ 10MB | BLOCK + ALERT |
| Email Deletion | NEVER | BLOCK + ALERT |
| External Forward | NEVER | BLOCK + ALERT |
| API Calls | Rate limited | 429 → BLOCK |

---

## 4. Time Boundaries — When This Bot Operates

| Period | Mode | Behavior |
|--------|------|----------|
| **9 AM - 7 PM IST** | ACTIVE | All allowed actions permitted |
| **7 PM - 9 AM IST** | READ-ONLY | No sends; alerts only |
| **Weekends** | SILENT | Monitoring only; no proactive actions |
| **Holidays** | SILENT | Per client calendar |

> **Validation Point:** If outside ACTIVE hours, BLOCK all WRITE/EXECUTE actions.

---

## 5. Geographic Boundaries — Where This Bot Operates

### 5.1 Allowed Locations

| Country | Code | Status |
|---------|------|--------|
| India | +91 | ✅ ALLOWED |
| United States | +1 | ✅ ALLOWED |

### 5.2 Blocked Locations

| All Other Countries | ❌ BLOCKED |

> **On Block Attempt:** Log event, alert ops team, deny action, notify client admin.

---

## 6. User Access — Who Can Use This Bot

### 6.1 Allowlist

| Email | Role | Channels | Permissions |
|-------|------|----------|-------------|
| `user1@client.com` | Admin | All | Full access |
| `user2@client.com` | User | Telegram, Slack | Standard |
| `user3@client.com` | User | Slack | Read-only |

### 6.2 Guest Access

- Guests can only QUERY (read-only)
- Guest messages logged
- External users: BLOCK after 3 attempts

### 6.3 Deny List

| User | Reason | Status |
|------|--------|--------|
| `[blocked_user]` | Security incident | PERMANENTLY BLOCKED |

---

## 7. Validation Engine — How SOUL Validates Actions

> **Before every action, the SOUL validator checks these 5 things:**

```
┌─────────────────────────────────────────────────────────────┐
│  SOUL VALIDATION ENGINE — PRE-EXECUTION CHECKS              │
├─────────────────────────────────────────────────────────────┤
│  1. CHANNEL — Is this channel in ALLOWED list?              │
│  2. USER — Is this user in the allowlist?                   │
│  3. ACTION — Is this action in ALLOWED list?                 │
│  4. TIME — Are we within ACTIVE hours?                      │
│  5. DATA — Is data within defined limits?                   │
├─────────────────────────────────────────────────────────────┤
│  IF ANY CHECK FAILS → BLOCK ACTION → LOG EVENT → ALERT     │
└─────────────────────────────────────────────────────────────┘
```

### 7.1 High-Risk Actions (Require Extra Validation)

| Action | Requires | Escalation Path |
|--------|----------|----------------|
| `delete-data` | Admin + 2-factor | Immediate SMS alert |
| `modify-calendar` | User confirmation | Email to ops |
| `external-send` | User + Admin | Full audit trail |
| `download > 5MB` | Admin approval | Block + log |

### 7.2 Validation Logic (Pseudocode)

```python
def validate_action(user, channel, action, data=None, time_now=None):
    errors = []

    # 1. Channel Check
    if channel not in soul.allowed_channels:
        errors.append(f"CHANNEL_BLOCKED: {channel}")

    # 2. User Check
    if user not in soul.allowed_users:
        errors.append(f"USER_NOT_ALLOWED: {user}")

    # 3. Action Check
    if action not in soul.allowed_actions:
        errors.append(f"ACTION_BLOCKED: {action}")

    # 4. Time Check
    if not soul.is_active_hours(time_now):
        errors.append("OUTSIDE_ACTIVE_HOURS")

    # 5. Data Check
    if data.size > soul.max_attachment_size:
        errors.append(f"DATA_LIMIT_EXCEEDED: {data.size}")

    return len(errors) == 0, errors
```

---

## 8. Safety Guards — Alerting & Blocking System

### 8.1 Alert Triggers

| Event | Severity | Notification Method |
|-------|----------|---------------------|
| BLOCKED action attempt | Medium | Slack #alerts |
| External login detected | High | SMS + Email |
| Failed auth > 3x | Medium | Slack #alerts |
| Rate limit exceeded | Low | Log only |
| Attachment > 10MB | High | Block + Alert |
| New user added | Info | Log to audit |
| SOUL violation | Critical | Immediate ops page |

### 8.2 Alert Recipients

| Priority | Channel | Contact |
|----------|---------|---------|
| Critical | SMS | `@security-phone` |
| High | Telegram | `@ops-team` |
| Medium | Slack | `#clawops-alerts` |
| Low | Email | `ops@client.com` |

### 8.3 Emergency Shutdown

> **Command:** Type `STOP` in any channel
>
> **Effect:**
> 1. Bot disabled immediately
> 2. All admins alerted
> 3. Logs preserved
> 4. No further actions processed

---

## 9. Audit Trail — What Gets Logged

### 9.1 Log Format

Every action is logged as:

```log
[TIMESTAMP] | [USER] | [CHANNEL] | [ACTION] | [STATUS] | [DETAILS] | [DURATION]
2026-02-06T15:30:00Z | user1@client.com | Telegram | query-emails | ALLOWED | unread:5 | 0.234s
2026-02-06T15:31:22Z | user2@client.com | Slack | send-external | BLOCKED | external@other.com | 0.045s
2026-02-06T15:35:00Z | user3@client.com | Telegram | delete-data | BLOCKED | attempt:delete | 0.012s
```

### 9.2 Audit Requirements

| Item | Required |
|------|----------|
| Timestamp | ✅ UTC ISO 8601 |
| User identifier | ✅ Email or ID |
| Channel | ✅ Source channel |
| Action | ✅ Exact action name |
| Status | ✅ ALLOWED/BLOCKED |
| Details | ✅ Context (query, limits, etc.) |
| Duration | ✅ Execution time |

---

## 10. Approval Workflow — Adding New Use Cases

```
1. CLIENT SUBMITS REQUEST
      ↓
2. CLAWOPS REVIEWS SOUL IMPLICATIONS
      ↓
3. SECURITY ASSESSMENT (Is it safe?)
      ↓
4. SOUL.MD UPDATED (Add to allowed actions)
      ↓
5. DEPLOY NEW VERSION
      ↓
6. CLIENT NOTIFICATION
      ↓
7. MONITOR FOR ANOMALIES (48h)
```

### SOUL Versioning

| Version | Date | Changes | Approved By |
|---------|------|---------|-------------|
| 1.0.0 | 2026-02-06 | Initial deployment | Akshay |
| 1.1.0 | YYYY-MM-DD | `[change description]` | `[approver]` |

---

## 11. Compliance Notes

| Requirement | Status |
|-------------|--------|
| Data residency | Client-controlled |
| Encryption at rest | ✅ Enabled |
| Encryption in transit | ✅ TLS 1.3 |
| Access logging | ✅ Full audit trail |
| Incident response | ✅ 24h SLA |

---

## 12. Immutability Configuration

### Filesystem Lockdown

| Component | Status | Notes |
|-----------|--------|-------|
| Core OpenClaw | 🔒 IMMUTABLE | Cannot be modified after deployment |
| Skills | 🔒 IMMUTABLE | Fixed set, no changes |
| USE_CASES | 🔒 IMMUTABLE | Only approved use cases loaded |
| memory/ | 🔓 MUTABLE | Long-term memory storage |
| data/ | 🔓 MUTABLE | User data storage |
| logs/ | 🔓 MUTABLE | Logs and audit trail |

### Edit Token Workflow

```
Client requests change
      ↓
ClawOps generates token: immutability_manager.py --generate-token --client [name]
      ↓
Token sent securely (Signal/encrypted)
      ↓
Client unlocks: immutability_manager.py --unlock --token [TOKEN]
      ↓
Client makes changes
      ↓
Client relocks: immutability_manager.py --relock
      ↓
System auto-verifies integrity
```

### Token Configuration

| Setting | Value | Notes |
|---------|-------|-------|
| Token validity | 60 minutes | Single-use window |
| Storage | /opt/clawops/.edit_tokens.json | Restricted access |
| Generation | Via CLI only | python3 immutability_manager.py --generate-token --client [name] |

---

## 13. Metadata (For Validator)

```yaml
_meta:
  version: "1.0.0"
  use_case_path: "./USE_CASES"  # Path to approved use case files
  validator_script: "/opt/clawops/scripts/soul_validator.py"
  immutability_script: "/opt/clawops/scripts/immutability_manager.py"
  last_validated: "YYYY-MM-DD"
  last_locked: "YYYY-MM-DD HH:MM:SS UTC"
```

---

## Emergency Contacts

| Role | Contact |
|------|---------|
| ClawOps Ops | `ops@dooziesoft.com` |
| Client IT | `[client-it-email]` |
| Security Incident | `security@dooziesoft.com` |
| ClawOps Phone | `[24/7 number]` |

---

*This SOUL document is the **source of truth** for bot behavior. Changes require approval, versioning, and testing. DENY ALL is not a limitation — it's a feature.*

**Document Version:** 1.0  
**Last Updated:** February 2026  
**Next Review:** YYYY-MM-DD
